#include <array>
#include <ctime>
#include <random>
#include <algorithm>
#include "Stack.h"

Stack::Stack(void)
{
	//shuffleStack()
	
	//count will keep track of the place in the deck array
	int count = 0;
	//countpip1 is a counter variable to track iterations of loop
	//it will also keep populate the dominoes, pip1 starting from 0
	//For each value of pip1, pip2 ranges from 0-6
	for (int countpip1 = 0; countpip1 <= MAX_PIPS; countpip1++) {
		for (int countpip2 = countpip1; countpip2 <= MAX_PIPS; countpip2++) {
			//defaultly constructs dominoes as white and adds domino to deck
			deck[count] = Domino(countpip1,countpip2,'W');
			//increments count
			count++;
		}
	}

	//size of the deck is set equal to the value of count, which should be 28
	size = count;

	//shuffles the deck when constructed
	shuffleStack();
}

int Stack::getSize () const {
	return size;
}

int Stack::getTop() const {
	return (size-1);
}

void Stack::shuffleStack () {
	/*
		ctime::time()
		random::srand()
		string::begin()
		string::end()
		std::random_shuffle()
	*/


	//seeds the random number generator
	srand(time(0));
	//shuffles the stack
	random_shuffle(begin(deck), end(deck));
	return;
}

void Stack::remakeStack (char color) {
	//shuffleStakc()

	//count will keep track of the place in the deck array
	int count = 0;
	//countpip1 is a counter variable to track iterations of loop
	//it will also keep populate the dominoes, pip1 starting from 0
	//For each value of pip1, pip2 ranges from 0-6
	for (int countpip1 = 0; countpip1 <= MAX_PIPS; countpip1++) {
		for (int countpip2 = countpip1; countpip2 <= MAX_PIPS; countpip2++) {
			//constructs a domino of the specifications and adds to deck
			deck[count] = Domino(countpip1,countpip2,color);
			count++;
		}
	}
	//size of the deck is set equal to the value of count, which should be 28
	size = count;

	//shuffles the deck when constructed
	shuffleStack();
}

string Stack::getStack () const {
	//Domino::getDomino()

	//string to be returned
	string output;
	//count will keep track of the place in the array
	for (int count = 0; count < size; count++) {
		//concatenates to output, Domino in string form with a space after 
		output += deck[count].getDomino() + " ";
	}

	return output;
}
Domino Stack::drawFromStack () {
	//if deck is empty
	if (size == 0) {
		exit(EXIT_FAILURE);
	}
	//otherwise return the index of size-1, and decrease size by 1, as the domino has been drawn
	else {
		return (deck[--size]);
	}

}

Domino Stack::getTopOfStack () const {
	//getTop()

	//if deck is empty
	if (size == 0) {
		exit(EXIT_FAILURE);
	}
	else {
		return (deck[getTop()]);
	}
}

Stack::~Stack(void)
{
}

void Stack::copy(Stack input) {
	//Domino::copy()

	for (int count = 0; count < input.size; count++) {
		deck[count].copy(input.deck[count]);
	}
	size = input.size;
}

Domino* Stack::get(int input){
	//returns the address of the domino at that index
	if (input < size) {
		return &deck[input];
	}
	else {
		//returns empty domino
		Domino* nope = new Domino;
		return nope;
	}
}

int Stack::getMax() const {
	return MAX_DECK_SIZE;
}

int Stack::setSize(int input) {
	//validates input
	if (input >= 0 && input <= MAX_DECK_SIZE) {
		size = input;
		return 0;
	}
	return -1;
}

void Stack::copy(Domino input[], int size) {
	//Domino::copy()

	//copies up to size or Max deck size number of dominoes into the stack
	for (int count = 0; count < size; count++) {
		if (count >= MAX_DECK_SIZE) {
			break;
		}
		deck[count].copy(input[count]);
	}
	//sets the new size of the deck equal to the size of the array or if the array exceeds max deck size, the max deck size
	if (size <= MAX_DECK_SIZE) {
		this->size = size;
	}
	else {
		this->size = MAX_DECK_SIZE;
	}
}