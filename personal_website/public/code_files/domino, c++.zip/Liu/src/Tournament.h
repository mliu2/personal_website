#pragma once
#include "Player.h"
#include "Game.h"

class Tournament
{
public:
	Tournament(void);
	~Tournament(void);

	/* *********************************************************************
	Function Name: startTour
	Purpose: starts the Tournament
	Parameters: none
	Return Value: none
	Local Variables:
			input, a character that records user inputs
			endOfGame, a string that records how the startGame's return value, which 
				tells the code how the game ended (if anyone won, or if the user asked to save)
			saveTry, an integer that records if the saveGame function was successful
			inputFileName, a string that records the user's input of a filename to load from
			saveFile, an input filestream that is used to check if the user's file can be opened (or indeed exists)
			canOpen, a boolean that holds if the user's file can be opened
	Algorithm:	1) User input on New game or Load game
				2a) If load is selected, the loadGame function is called, and the loading is verified
				2b) If new game is selected, then newGame function is called
				3) The startGame function is called, the return value is recorded
				4a) If the return value is "S", the game saves and exits
				4b) If anything else, the roundWinner parses who won and increases the score
				5) The User prompted for playing again
				6a) If "Y", keepPlaying calls newGame
				6b) If "N", the tournament exits
	Assistance Received: A. Krygoksi
	********************************************************************* */
	void startTour();
	/* *********************************************************************
	Function Name: keepPLaying
	Purpose: checks if the user wishes to keep playing
	Parameters: character input, which will nonesize of the Stack object
	Assistance Received: none
	********************************************************************* */
	void keepPlaying(char input);
	/* *********************************************************************
	Function Name: endOfTour
	Purpose: Returns the player that won the tournament as a string.
	Parameters: none
	Return Value: name of player that won the tournament or "draw"
	Assistance Received: none
	********************************************************************* */
	string endOfTour ();
	/* *********************************************************************
	Function Name: saveGame
	Purpose: saves the game to a .txt file
	Parameters: none
	Return Value: integer for whether or not the save was successful
	Local Variables:
				input, a character which takes the input from the user on overwriting or not
				fileName, a string which takes input from user on the file to save to
				tryFile, an input file stream that checks if the file already exists
				saveFile, an output file stream that allows saving of the data
	Algorithm: 
				1) Asks user for input on file, if file already exists, ask to overwrite. If the user
					does not wish to overwrite, ask for input again
				2) Calls functions to get strings of the each of the elements and puts it into the filestream
				3) Exit the program.
	Assistance Received: none
	********************************************************************* */
	int saveGame();
	/* *********************************************************************
	Function Name: roundWinner
	Purpose: Increments the score of the player that won the round
	Parameters: string input to indicate who won the tournament
	Return Value: none
	Assistance Received: none
	********************************************************************* */
	void roundWinner(string input);
	/* *********************************************************************
	Function Name: loadGame
	Purpose: loads the game from a text file
	Parameters: string filename, the name of the file to be saved to
	Return Value: integer indicates whether or not the load was successful
	Local Variables:
				MAX_DOMINOES, a const integer which indicates the maximum size of the boneyard
				loadfile, a input filestream which will open the file of the input
				temp, a string that is used to hold each line as it is being processes
				loadState, an integer which keeps track of whether or not the file loaded properly
				domArr, an array of dominoes that holds the dominoes that were parsed
				arrCount, an integer that holds the size of the domArr
				emptyStr, a const string that holds the value of an empty string
				stacks, boneyard, hand, score, round, and turn, regexs that helps the code find the values to pass into the domArr

	Algorithm:	1) The function will read each line into a string.
				2) For each line, the function will erase the label.
				3) The value after each line is parsed and the appropriate value is set.
				4) If the number of stacks is 0, hands are set to 0, and 0 is returned, indicating a new game is needed
				5) A switch case statement determines the hands by counting the number of tiles left in the boneyard;
					the default statement will set loadState to -1, indicating that an improper number of tiles is left.
				6) A erase function will delete any whitespaces preceding the line
				7) If the turn is set, it will translate call setTurn
				8) -2 is returned if loadstate is -1; 1 is returned on successful load; -1 on failed load
	Assistance Received: none
	********************************************************************* */
	int loadGame(string filename);

	
private:
	Game game1;
	//number of rounds player has won
	int playerWins;
	//number of rounds computer has won
	int cpuWins;
};

