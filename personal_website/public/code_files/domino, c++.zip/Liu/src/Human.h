#pragma once
#include "player.h"
class Human :
	public Player
{
public:
	Human(void);
	~Human(void);

	/* *********************************************************************
	Function Name: getColor
	Purpose: gets the color of the human's tiles
	Parameters: none
	Return Value: none
	Assistance Received: none
	********************************************************************* */
	char getColor() const;

	/* *********************************************************************
	Function Name: remake
	Purpose: completely resets the human's boneyard
	Parameters: none
	Return Value: none
	Assistance Received: none
	********************************************************************* */
	void remake();
	
	/* *********************************************************************
	Function Name: beginStack
	Purpose: draws 6 dominoes from the human's stack to put onto the field
	Parameters: a pointer to an array of dominoes that is the field
	Return Value: none
	Assistance Received: none
	********************************************************************* */
	void beginStack(Domino* field);
private:
	static const char COLOR = 'B';
	static const char ENEMY = 'W';
};

