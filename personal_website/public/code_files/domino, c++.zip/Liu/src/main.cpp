/************************************************************
 * Name:  Mingzhao Liu                                      *
 * Project:  1                                              *
 * Class:  OPL 366                                          *
 * Date:  9/25/14                                           *
 ************************************************************/



#include <iostream>
#include <sstream>
#include <fstream>
#include "domino.h"
#include "Stack.h"
#include "board.h"
#include "Player.h"
#include "Game.h"
#include "Human.h"
#include "Tournament.h"
using namespace std;

/*Classes
   Basic
	Domino()
	Stack()
	Board()
	Player()
	Game()
	Tournament()
   Derived
	BoardView()
	Human()
	Computer()B
*/

int main () {

	//main()
	//Tournament::startTour()
	//Tournament::endTour()
	Tournament test;
	test.startTour();
	cout << test.endOfTour() << endl;
}