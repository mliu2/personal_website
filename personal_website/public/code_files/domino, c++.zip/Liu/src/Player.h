#pragma once
#include "Stack.h"

class Player
{
public:
	Player(void);
	~Player(void);

	/* *********************************************************************
	Function Name: getStart
	Purpose: gets the value of the player's starting tile
	Parameters: none
	Return Value: integer value of the player's starting tile
	Assistance Received: none
	********************************************************************* */
	int getStart() const;
	/* *********************************************************************
	Function Name: getScore
	Purpose: gets the player's current score
	Parameters: none
	Return Value: integer value of the player's score
	Assistance Received: none
	********************************************************************* */
	int getScore() const;
	/* *********************************************************************
	Function Name: getHand
	Purpose: gets the player's hand as a string
	Parameters: none
	Return Value: string that holds the player hand
	Assistance Received: none
	********************************************************************* */
	string getHand() const;
	/* *********************************************************************
	Function Name: getHandSize
	Purpose: gets the size of the player's hand
	Parameters: none
	Return Value: integer value of the player's current hand size
	Assistance Received: none
	********************************************************************* */
	int getHandSize() const;
	/* *********************************************************************
	Function Name: getPass
	Purpose: gets if the player passed last turn
	Parameters: none
	Return Value: boolean value that indicates if the player passed last turn
	Assistance Received: none
	********************************************************************* */
	bool getPass() const;
	/* *********************************************************************
	Function Name: getBoneyard
	Purpose: gets the player's boneyard as a string
	Parameters: none
	Return Value: a string that holds the boneyard
	Assistance Received: none
	********************************************************************* */
	string getBoneyard() const;

	/* *********************************************************************
	Function Name: setScore
	Purpose: Sets a player's total score
	Parameters: integer inputScore that score will be set to 
	Return Value: none
	Assistance Received: none
	********************************************************************* */
	void setScore(int inputScore);
	/* *********************************************************************
	Function Name: setPass
	Purpose: Sets if the player passed last turn
	Parameters: boolean input that if the player passed last turn will be set to
	Return Value: none
	Assistance Received: none
	********************************************************************* */
	void setPass(bool input);
	/* *********************************************************************
	Function Name: setBoneyard
	Purpose: Sets the player's boneyard
	Parameters: array of Dominoes that the boneyard will be set to, and the size of that array
	Return Value: none
	Assistance Received: none
	********************************************************************* */
	void setBoneyard(Domino input[], int size);
	/* *********************************************************************
	Function Name: setHand
	Purpose: Sets the player's hand
	Parameters: array of Dominoes that the hand will be set to, and the size of that array
	Return Value: none
	Assistance Received: none
	********************************************************************* */
	void setHand(Domino input[], int size);
	/* *********************************************************************
	Function Name: setStart
	Purpose: Set the player's start value
	Parameters: none
	Return Value: none
	Assistance Received: none
	********************************************************************* */
	void setStart();
	/* *********************************************************************
	Function Name: setStart
	Purpose: Set the player's start value
	Parameters: integer input that the player's start value will be set to
	Return Value: none
	Assistance Received: none
	********************************************************************* */
	void setStart(int input);
	/* *********************************************************************
	Function Name: emptyHand
	Purpose: empties the player's hand
	Parameters: none
	Return Value: none
	Assistance Received: none
	********************************************************************* */
	void emptyHand();
	

	/* *********************************************************************
	Function Name: drawDomino
	Purpose: draws up to MAX_HAND_SIZE dominos 
	Parameters: none
	Return Value: none
	Assistance Received: none
	********************************************************************* */
	void drawDomino();
	/* *********************************************************************
	Function Name: placeDomino
	Purpose: plays a domino from the hand 
	Parameters: integer tile, the index of the tile in hand
				integer location, index on the field that the tile will be played at
				domino pointer to an array field that the tile will be played on
	Return Value: none
	Assistance Received: none
	********************************************************************* */
	int placeDomino(int tile, int location, Domino* field);
	/* *********************************************************************
	Function Name: tryPlaceDomino
	Purpose: checks if the move is legal
	Parameters: integer tile, the index of the tile in hand
				integer location, index on the field that the tile will be played at
				domino pointer to an array field that the tile will be played on
	Return Value: a boolean that holds if the move is legal
	Assistance Received: none
	********************************************************************* */
	bool tryPlaceDomino(int tile, int location, Domino* field);
	/* *********************************************************************
	Function Name: pass
	Purpose: to indicate that the player passes
	Parameters: none
	Return Value: a string "pass" to indicate that the player passed
	Assistance Received: none
	********************************************************************* */
	string pass();
	/* *********************************************************************
	Function Name: handSort
	Purpose: sorts the hand by moving empty dominoes to the higher indexes
	Parameters: none
	Return Value: none
	Assistance Received: none
	********************************************************************* */
	void handSort();
	/* *********************************************************************
	Function Name: handScorePenalty
	Purpose: calculate the player's penalty for not playing cards
	Parameters: none
	Return Value: integer of the value that should be subtracted from their score
	Assistance Received: none
	********************************************************************* */
	int handScorePenalty();

	/* *********************************************************************
	Function Name: thinkCPU
	Purpose: computer playing algorithm, computer will see which move is best and print why, 
	Parameters: pointer to an array of dominoes Field that the code will look for plays on
				character enemyColorthat tells which colored tiles are the enemies
				bool wantHelp that tells the code if the code should print its reasoning
	Return Value: a string that holds the "stack name:IndexOfTileInHand" the code thinks shoud be played
	Local Variables: handTile, integer that holds the index of the tile in hand 
					fieldLocation, integer that holds the index of the stack on the board
					field2, integer that holds the index of another stack on the board, helps find nonopposed enemy tiles
					allSelf, a boolean that if the only tiles on the board are owned by the player
					legal, a boolean that holds if the move is legal
					output, a string that outs the output
					reason, an integer that holds the string to be output
					location, a string that holds the name of the stack to hold it
					printStr, a string that holds the tile, location, and reason why the code picked it
	Algorithm:	1) find the first opposing stack
				2) find the lowest opposing stack
				3) if there are not opposing stacks, pick the lowest stack
				4) find the first tile that can be played that is not a double
				5) if no non doubles can be played, check for the first double
					a) if no doubles exists, set reason to 0
					b) find the first nondouble opposing tile
						i) find the largest non double opposing tile
						ii) find the lowest double in hand
					c) if the location is also a double
						i) find lowest double that is greater than the location's value
				6) finds the lowest that can be played
				7) checks if the move is legal
				8) converts fieldLocation to a string stored in location
				9) sets output string accordingly
				10) if the wantadvice is true, print printStr
	Assistance Received: none
	********************************************************************* */
	string thinkCPU(Domino* field, char enemyColor, bool wantHelp);
	/* *********************************************************************
	Function Name: parseStackName
	Purpose: parse a string of a stack name into a location on the board
	Parameters: string input of a stack name
	Return Value: integer index of the stack
	Assistance Received: none
	********************************************************************* */
	int parseStackName(string input);
	/* *********************************************************************
	Function Name: shuffleDeck
	Purpose: shuffles the boneyard
	Parameters: none
	Return Value: none
	Assistance Received: none
	********************************************************************* */
	void shuffleDeck();

protected:
	//total value of the starting tile to determine which player goes first
	int start;
	//index in array where the player's tiles start
	static const int PLAYER_TILE_START = 6;
	//score of the player;
	int score;
	//current handsize
	int handsize;
	//maximum hand size
	static const int MAX_HAND_SIZE = 6;
	//maximum number of stacks
	static const int MAX_STACKS = 12;
	//player's boneyard
	Stack boneyard;
	//holds player's hand
	Domino hand[MAX_HAND_SIZE];
	//if player passed last turn
	bool didPass;
	static const char COMPUTER = 'W';
	static const char HUMAN = 'B';
};

