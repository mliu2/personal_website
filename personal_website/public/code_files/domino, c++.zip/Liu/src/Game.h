#pragma once
#include <fstream>
#include "Player.h"
#include "Computer.h"
#include "Human.h"
#include "BoardView.h"
#include "domino.h"

class Game
{
public:
	Game(void);
	~Game(void);
	void setHands (int input);
	int getHands () const;
	
	/* *********************************************************************
	Function Name: getBoard
	Purpose: gets the board object as a pointer
	Parameters: none
	Return Value: board object being used
	Assistance Received: none
	********************************************************************* */
	BoardView* getBoard();
	/* *********************************************************************
	Function Name: getHuman
	Purpose: gets the Human object as a pointer
	Parameters: none
	Return Value: Human object being used
	Assistance Received: none
	********************************************************************* */
	Human* getHuman();
	/* *********************************************************************
	Function Name: getComputer
	Purpose: gets the Computer object as a point
	Parameters: none
	Return Value: Computer object being used
	Assistance Received: none
	********************************************************************* */
	Computer* getComputer();
	/* *********************************************************************
	Function Name: getTurn
	Purpose: gets an integer that represents whose turn it is
	Parameters: none
	Return Value: an integer that represents whose turn it is; 0 is for computer, 1 is for player
	Assistance Received: none
	********************************************************************* */
	int getTurn() const;
	/* *********************************************************************
	Function Name: getWinner
	Purpose: gets the winner of the round
	Parameters: none
	Return Value: a string that holds the winner of the round
	Assistance Received: none
	********************************************************************* */
	string getWinner() const;


	/* *********************************************************************
	Function Name: setTurn
	Purpose: Sets the integer that holds whose turn it is
	Parameters: integer input that determines whose turn it is
	Return Value: none
	Assistance Received: none
	********************************************************************* */
	void setTurn(int input);
	/* *********************************************************************
	Function Name: newGame
	Purpose: Sets up the parameters for a new game
	Parameters: none
	Return Value: none
	Assistance Received: none
	********************************************************************* */
	void newGame();
	/* *********************************************************************
	Function Name: startGame
	Purpose: starts the game 
	Parameters: none
	Return Value: a string that holds the winner of the game
	Local Variables: input, a string that holds the user's input
					mayPass, a string that holds whether or not the player is alloed to pass
					tileinput, an integer that holds the index of the domino the player to chose to play
					legalMove, an integer that holds whether or not the player's move is legal

	Algorithm:	1) Checks which player has the higher start value 
				2) Sets the turn variable accordingly
				3) Begin a loop that exits if it passes the last hand or if the user askes to save
				4) If both hands are empty, or if both players passed
					a) tally the score for both player
					b) draws a new hand for both players
					c) ends the hand
					d) if it is the last hand, break out of the loop
				5) if it is the computer's turn
					a) print the game state
					b) sort the computer's hand and then it plays
					c) ask user for input on saving or continuing
					d) if the user picks save, break out of the loop
					e) sets the turn variable to the player's turn
				6) if it is the player's turn
					a) prints the game state
					b) check if user can pass
					c) prompt user and validate input
					d) if user asked for help, call thinkCPU function
					e) if user asked to save, break out of loop
					f) if user inputs tile index and location, validate the move
					g) if user's move is valid, then play it
					h) if user inputs pass, or if user's move is valid, set the turn to computer's turn
					i) if both hands are empty, break out of the loop
				7) at the end of the loop, if the loop was broken due to user asking to save, return "S"
					a) if the loop was broken due to end of game, print both player's scores
					b) return the winner of the game, determined by the getWinner function

	Assistance Received: none
	********************************************************************* */
	string startGame();
	/* *********************************************************************
	Function Name: shuffleGame
	Purpose: shuffles both player's boneyards and gets a new start tile and prints the value
	Parameters: none
	Return Value: none
	Assistance Received: none
	********************************************************************* */
	void shuffleGame();
	
	/* *********************************************************************
	Function Name: printGameState
	Purpose: couts the current board with stack names and the player's hand with index labels
	Parameters: none
	Return Value: none
	Assistance Received: none
	********************************************************************* */
	void printGameState();

protected:
	BoardView table;
	Human playerH;
	Computer playerC;
	static const int MAX_HANDS = 4;
	int hands;
	//keeps track of whose turn; 0 is CPU, 1 is player
	int turn;
};

