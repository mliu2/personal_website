#include "Human.h"


Human::Human(void)
{
	//Stack::remakeStack()

	boneyard.remakeStack(COLOR);
}


Human::~Human(void)
{
}

char Human::getColor() const {
	return COLOR;
}


void Human::remake() {
	//Stack::remakeStack()

	boneyard.remakeStack(COLOR);
}

void Human::beginStack(Domino* field) {
	/*
		Stack::drawFromStack()
		Domino::copy()
		setStart()
	*/

	//draws 6 tiles from each boneyard to use as the board
	for (int count = PLAYER_TILE_START; count < MAX_STACKS; count++) {
		field[count].copy(boneyard.drawFromStack());
	}
	setStart();

}