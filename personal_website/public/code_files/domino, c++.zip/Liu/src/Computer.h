#pragma once
#include "player.h"
class Computer :
	public Player
{
public:
	Computer(void);
	~Computer(void);

	/* *********************************************************************
	Function Name: getColor
	Purpose: gets the color of the computer's tiles
	Parameters: none
	Return Value: none
	Assistance Received: none
	********************************************************************* */
	char getColor() const;

	/* *********************************************************************
	Function Name: remake
	Purpose: completely resets the computer's boneyard
	Parameters: none
	Return Value: none
	Assistance Received: none
	********************************************************************* */
	void remake();
	/* *********************************************************************
	Function Name: beginStack
	Purpose: draws 6 dominoes from the computer's stack to put onto the field
	Parameters: a pointer to an array of dominoes that is the field
	Return Value: none
	Assistance Received: none
	********************************************************************* */
	void beginStack(Domino* field);
	/* *********************************************************************
	Function Name: playCPU
	Purpose: the computer will try to play a tile
	Parameters: a pointer to an array of dominoes that is the field
	Return Value: none
	Assistance Received: none
	********************************************************************* */
	void playCPU(Domino* field);
private:
	static const char COLOR = 'W';
	static const char ENEMY = 'B';
};

