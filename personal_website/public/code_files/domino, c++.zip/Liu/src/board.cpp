#include "board.h"
#include "Stack.h"


Board::Board(void)
{
	//creates a new field
	field = new Domino[MAX_FIELD_SIZE];
}


Board::~Board(void)
{
	delete [] field;
}

int Board::getScore (char color) const{
	/*
		Domino::getColor()
		Domino::getValue()
	*/

	int score = 0;
	//adds up the value of the dominoes on the board of the player's color
	for (int count = 0; count < MAX_FIELD_SIZE; count++) {
		if (field[count].getColor() == color) {
			score +=field[count].getValue();
		}
	}
	return score;
}
void Board::setField(Domino input[], int size, int start) {
	//Domino::copy()

	//copies up to size or until the max field size is reached number of dominoes from input at index start to the same index on the board
	for (int count = start; count < MAX_FIELD_SIZE; count++) {
		if ((count-start) < size) {
			field[count].copy(input[count]);
		}
	}
}
Domino* Board::getField() const{
	return field;
}

void Board::copy(Board input) {
	//Domino::copy()

	//copies every domino from an input board
	for (int count = 0; count < MAX_FIELD_SIZE; count++) {
		field[count].copy(input.field[count]);
	}
}

void Board::copy(Domino input[], int size) {
	//Domino::copy()

	//copies every domino from an input array until size or Max field size is reached
	for (int count = 0; count < size; count++) {
		if (count >= MAX_FIELD_SIZE) {
			break;
		}
		field[count].copy(input[count]);
	}
}