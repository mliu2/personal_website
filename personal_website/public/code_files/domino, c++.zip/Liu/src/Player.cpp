#include <sstream>
#include "Player.h"


Player::Player(void)
{
	didPass = false;
	score = 0;
	handsize = 0;
}


Player::~Player(void)
{
}

int Player::getScore() const{
	return score;
}

void Player::setScore(int inputScore) {
	score = inputScore;
}

int Player::getStart() const{
	return start;
}

void Player::setStart() {
	/*
		Stack::getTopOfStack()
		Domino::getValue()
	*/

	//set start equal to the total value of the top domino
	start = boneyard.getTopOfStack().getValue();
}

void Player::drawDomino() {
	/*
		Stack::getSize()
		Domino::copy()
	*/

	handsize = 0;
	//draws up to MAX HAND SIZE or until boneyard is empty
	for (int count = 0; count < MAX_HAND_SIZE; count++) {
		//if boneyard is empty, stop drawing
		if (boneyard.getSize() <= 0) {
			break;
		}
		//draws and adds domino to hand
		hand[count].copy(boneyard.drawFromStack());
		//updates handsize
		handsize++;
	}
}

int Player::placeDomino(int tile, int location, Domino* field) {
	/*
		Domino::copy()
		handSort()
	*/
	if (tryPlaceDomino(tile, location, field)) {
		field[location].copy(hand[tile]);
		//sets that tile to empty and lowers the handsize
		hand[tile].setColor('E');
		handsize--;
		handSort();
		//set player as not passing
		didPass = false;
		//1 is legal move
		return 1;
	}
	else {
		//-1 for illegal move
		return -1;
	}
}

bool Player::tryPlaceDomino(int tile, int location, Domino* field) {
	/*
		Domino::getColor()
		Domino::getDouble()
		Domino::getValue()
	*/
	
	//default is illegal move
	bool canPlace = false;
	//checks if the tile is empty
	if (hand[tile].getColor() == 'E') {
		//illegal move
		return canPlace;
	}
	//if tile index exceeds handsize
	if (tile >= handsize) {
		//illegal move
		return canPlace;
	}

	//if the tile is a double
	if (hand[tile].getDouble()) {
		//if the location is also a double
		if (field[location].getDouble()) {
			//check if value of tile is greater
			if (hand[tile].getValue() > field[location].getValue()) {
				//if so, the tile can be played
				canPlace = true;
				return canPlace;
			}
			//-1 for illegal move
			else {
				return canPlace;
			}
		}
		//if location is not a double
		else {
			//the double tile can be played
			canPlace = true;
			return canPlace;
		}
	}
	else {
		//check for if value of tile is greater
		if (hand[tile].getValue() >= field[location].getValue()) {
			//if so, the tile can be played
			canPlace = true;
			return canPlace;
		}
		//-1 for illegal move
		else {
			return canPlace;
		}
	}
}

string Player::pass() {
	didPass = true;
	return "pass";
}

void Player::setPass(bool input) {
	didPass = input;
}

string Player::getHand() const{
	//Domino::getColor()
	//Domino::getDomino()

	//string to be returned
	string retHand = "Hand: ";
	//gets only the dominoes in the hand that do not have color 'E', indicating that they are empty
	for (int count = 0; count < handsize; count++) {
		if (hand[count].getColor() == 'B' || hand[count].getColor() == 'W') {
			retHand = retHand + hand[count].getDomino() + " ";
		}
	}

	return retHand;
}


void Player::handSort() {
	//Domino::getColor()
	//Domino::copy()
	//Domino::setColor()

	//for loops through hand
	for (int count = 0; count < MAX_HAND_SIZE; count++) {
		if (hand[count].getColor() == 'E') {
			//if there are any empty tiles, look for the first tile from the back that is not empty
			for (int countBack = MAX_HAND_SIZE-1; countBack > count; countBack--) {
				if (hand[countBack].getColor() != 'E') {
					//copy the values of the non empty tile into the empty tile and set the tile's original index to empty
					hand[count].copy(hand[countBack]);
					hand[countBack].setColor('E');
					break;
				}
			}
		}
	}

}
int Player::getHandSize() const{
	return handsize;
}

bool Player::getPass() const{
	return didPass;
}

int Player::handScorePenalty() {
	//Domino::getValue()

	int score = 0;
	//adds up the values of the tiles in the player's hand
	for (int count = 0; count < handsize; count++) {
		score += hand[count].getValue();
	}
	return score;
}

string Player::getBoneyard() const{
	//Stack::getStack()

	return boneyard.getStack();
}

void Player::setBoneyard(Domino input [], int size) {
	/*
		Stack::getMax()
		Stack::get()
		Domino::copy()
		Stack::setSize()
	*/

	for (int count = 0; count < size; count++) {
		if (count >= boneyard.getMax()) {
			break;
		}
		boneyard.get(count)->copy(input[count]);
	}
	boneyard.setSize(size);
}

void Player::setHand(Domino input[], int size) {
	//Domino::copy()

	//copies dominoes from an array until the input size is reached or the maximum handsize is reached
	for (int count = 0; count < size; count++) {
		if (count >= MAX_HAND_SIZE) {
			break;
		}
		hand[count].copy(input[count]);
	}
	handsize = size;
}

void Player::setStart(int input) {
	//validates input
	if (input == 1 || input == 0) {
		start = input;
	}
}

void Player::emptyHand() {
	//Domino::setColor()

	//sets all dominoes in the hand to empty
	for (int count = 0; count < MAX_HAND_SIZE; count++) {
		hand[count].setColor('E');
	}
}

string Player::thinkCPU(Domino* field, char enemyColor, bool wantHelp) {
	/*
		Domino::getColor()
		Domino::getValue()
		Domino::getDouble()
		tryPlace()
		std::to_string()
		Domino::getDomino()
	*/
	//holds index of tile from hand
	int handTile = -1;
	//holds the location of a tile on the board
	int fieldLocation = -1;
	//helps find highest non double opposed tile
	int field2 = -1;
	//true if only owned tiles are on board
	bool allSelf = false;
	//checks for illegal move
	bool legal;
	//output string tells what cpu chose; is returned
	string output = "pass";
	//reason; 0 is no mooves, 1 is lowest possble tile that can be played, 2 is found double to reset stack
	int reason;
	//string that holds the name of the stack to be returned
	string location;
	//string that holds the message to be printed
	string printStr;

	//finds the first opposing block
	for (int count = 0; count < MAX_STACKS; count++) {
		if (field[count].getColor() == enemyColor) {
			fieldLocation = count;
			break;
		}
	}
	//If no opposing blocks exist
	if (fieldLocation == -1) {
		fieldLocation = 0;
		allSelf = true;
		//finds the lowest valued block
		for (int count = 0; count < MAX_STACKS; count++) {
			if (field[count].getValue() < field[fieldLocation].getValue()) {
				fieldLocation = count;
			}
		}
	}
	else {
		//finds the lowest valued opposing block
		for (int count = 0; count < MAX_STACKS; count++) {
			if (field[count].getColor() == enemyColor) {
				if (field[count].getValue() < field[fieldLocation].getValue()) {
					fieldLocation = count;
				}
			}
		}
	}

	//-------------------------------tile on board located, find a tile in hand--------------
	//finds the first tile that is not a double that can be played
	for (int count = 0; count < handsize; count++) {
		if (hand[count].getDouble()) {
			continue;
		}
		else if (hand[count].getValue() >= field[fieldLocation].getValue()){
			handTile = count;
		}
	}
	//if no nondouble tiles can be played
	if (handTile == -1) {
		//finds the first double tile in hand
		for (int count = 0; count < handsize; count++) {
			if (hand[count].getDouble()) {
				handTile = count;
				break;
			}
		}
		//if no double tiles, no tiles can be played 
		if (handTile == -1) {
			reason = 0;
		}
		else {
			//finds the first non double opposing on the board
			for (int count = 0; count < MAX_STACKS; count++) {
				if ((!field[count].getDouble()) && field[count].getColor() == enemyColor) {
					field2 = count;
					break;
				}
			}
			//if nondouble opposing tiles
			if (field2 != -1) {
				fieldLocation = field2;
				//find the largest non double opposing on the board
				for (int count = 0; count < MAX_STACKS; count++) {
					if ((!field[count].getDouble()) && field[count].getColor() == enemyColor && field[count].getValue() > field[field2].getValue()) {
						fieldLocation = count;
					}
				}
				//finds the lowest double in hand
				for (int count = 0; count < handsize; count++) {
					if (hand[count].getDouble() && hand[count].getValue() < hand[handTile].getValue()) {
						handTile = count;

					}
				}
				//sets reason to be interepted later
				reason = 2;
			}
			//if target location is also a double tile
			else {
				//finds the first double tile in hand greater than selected tile
				handTile = -1;
				for (int count = 0; count < handsize; count++) {
					if (hand[count].getDouble() && hand[count].getValue() > field[fieldLocation].getValue()) {
						handTile = count;
						break;

					}
				} if (handTile != -1) {
					//finds the lowest double tile in hand greater than selected tile
					for (int count = 0; count < handsize; count++) {
						if (hand[count].getDouble() && hand[count].getValue() < hand[handTile].getValue() && hand[count].getValue() > field[fieldLocation].getValue()) {
							handTile = count;
						}
					}
					//sets reason to be interepted later
					reason = 1;
				}
			}
		}
	}
	//if nondouble tiles can be played on the lowest tile
	else {
		//find lowest nondouble tile that can be played
		for (int count = 0; count < handsize; count++) {
			if (!hand[count].getDouble() && hand[count].getValue() < hand[handTile].getValue() && hand[count].getValue() >= field[fieldLocation].getValue()) {
				handTile = count;
			}
		}
		//sets reason to be interepted later
		reason = 1;
	}
	//try the move, if it doesn't work, just pass
	//just in case
	if (reason == 1 || reason == 2) {
		//attempts to play
		legal = tryPlaceDomino(handTile, fieldLocation, field);
		//if illegal, passes
		if (legal == false) {
			reason = 0;
		}
	}

	//if the index on the board is less than 6, recognize that it is on the computer's side of the board
	//if the index on the board is greater than 6, recognize that it is on the humans's side of the board
	//then convert the index to a string of either "W[1-6]" or "B[1-6]" 
	//The +1 is because the index of the array starts at 0, but the stack names start from W1
	if (fieldLocation < PLAYER_TILE_START) {
		location = "W" + to_string(fieldLocation + 1);
	}
	else {
		location = "B" + to_string(fieldLocation - PLAYER_TILE_START + 1);
	}

	//inteprets the reason for the computer's play
	switch (reason) {
	case 0: 
		//no moves, reason is set to 0 by default
		printStr =  "AI picks passing; no moves available";
		output = "pass";
		break;
	case 1:
		//placed a the lowest tile of a higher value on the lowest tile
		printStr =  "AI picks " + hand[handTile].getDomino() + " on stack " + location + " because it is the lowest tile to play.";
		output = location + ":" + to_string(handTile);
		break;
	case 2:
		//placed a double on a start to reset it
		printStr =  "AI picks " + hand[handTile].getDomino() + " on stack " + location + " because it would reset the stack.";
		output = location + ":" + to_string(handTile);
		break;
	}

	//if the wantHelp is true, then the reason for the play will be printed
	if (wantHelp) {
		cout << printStr << endl;
	}

	return output;
}


int Player::parseStackName(string input) {

	//stackNumber fails translation by default
	int stackNumber = -1;
	//if the first character is the computer's color, the index begins at zero
	if (input[0] == COMPUTER) {
		stackNumber = 0;
	}
	//if the first character is the human's color, the index beings at six, where the player's side of the board starts
	else if (input[0] == HUMAN) {
		stackNumber = PLAYER_TILE_START;
	}

	//if the second chracter is a digit, translate char into a number to be added to stackNumber. Otherwise, translation fails
	if (input[1] >= '1' && input[1] <= '9') {
		//48 is the decimal value subtracted from an ASCII number character to obtain its value
		//one is more is subtracted because stacks start numbering from 1, but the index starts at 0
		stackNumber += (input[1] - 49);
	}
	else {
		stackNumber = -1;
	}
	//if the resulting stackNumber is negative, or exceeds the maximum number of stacks, the translation failed
	if (stackNumber < 0 || stackNumber >= MAX_STACKS) {
		stackNumber = -1;
	}
	//-1 indicates failed translation
	return stackNumber;
}

void Player::shuffleDeck() {
	//Stack::ShuffleStack()

	boneyard.shuffleStack();
}