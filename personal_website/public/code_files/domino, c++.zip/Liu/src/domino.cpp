#include <iostream>
#include <sstream>
#include "domino.h"
using namespace std;

Domino::Domino () {
	//default constructor creates a error 0-0 domino tile with color 'E'
	pip1 = 0;
	pip2 = 0;
	value = 0;
	isDouble = true;
	color = 'E';
}
Domino::Domino (int val1, int val2, char player) {
	//value of val1 is passed in
	pip1 = val1;
	//value of val2 is passed in
	pip2 = val2;
	//value of value is set to the total of pip1 and pip2
	value = pip1+pip2;
	//value of player is passed into color if the color is W(hite) or B(lack)
	if (player == 'W' || player == 'B') {
		color = player;
	}
	else {
		//White is default color
		color = 'W';
	}
	//compares pip1 and pip2 to determine if domino is a double domino
	if (pip1 == pip2) {
		isDouble = true;
	}
	else {
		isDouble = false;
	}
}

Domino::~Domino() {

}

int Domino::getValue () const{
	return value;
}

bool Domino::getDouble () const{
	return isDouble;
}

int Domino::getPip1 () const{
	return pip1;
}

int Domino::getPip2 () const{
	return pip2;
}

char Domino::getColor () const{
	return color;
}

string Domino::getDomino () const{
	//to_string()

	string tile = color + to_string(pip1) + to_string(pip2);
	
	return tile;
}

int Domino::setPip1(int input) {
	//validates the value of input
	if (input <= MAX_PIP && input >= 0) {
		pip1=input;
		value = pip1+pip2;
		//checks if new value would make the domino a double
		if (pip1 == pip2) {
			isDouble = true;
		}
		else {
			isDouble = false;
		}
		return 0;
	}
	return -1;
}
int Domino::setPip2(int input) { 
	//validates the value of input
	if (input <= MAX_PIP && input >= 0) {
		pip2=input;
		value = pip1+pip2;
		//checks if new value would make the domino a double
		if (pip1 == pip2) {
			isDouble = true;
		}
		else {
			isDouble = false;
		}
		return 0;
	}
	return -1;
}
int Domino::setColor(char input){
	//validates input
	if (input == 'W' || input == 'B' || input == 'E') {
		color = input;
		return 0;
	}
	return -1;
}

void Domino::copy(Domino input) {
	/*
		getColor()
		setColor()
		getPip1()
		setPip1()
		getPip2()
		setPip2()
		getDouble()
	*/

	setColor(input.getColor());
	setPip1(input.getPip1());
	setPip2(input.getPip2());
	isDouble = input.getDouble();
}