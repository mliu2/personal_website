#pragma once
#include "board.h"


class BoardView :
	public Board
{
public:
	BoardView();
	~BoardView();

	/* *********************************************************************
	Function Name: getStringCPUBoard
	Purpose: returns the computer's side of the board as a string 
	Parameters: none
	Return Value: a string with "Stack: " and then dominoes separated by spaces
	Assistance Received: none
	********************************************************************* */
	string getStringCPUBoard(void) const;
	/* *********************************************************************
	Function Name: getStringPlayerBoard
	Purpose: returns the human's side of the board as a string
	Parameters: none
	Return Value: a string with "Stack: " and then dominoes separated by spaces
	Assistance Received: none
	********************************************************************* */
	string getStringPlayerBoard(void) const;

	/* *********************************************************************
	Function Name: getStringCPUBoard
	Purpose: returns the computer's side of the board as a string
	Parameters: none
	Return Value: a string with "Stack: " the dominoes, and also their stack names
	Assistance Received: none
	********************************************************************* */
	string printBoard() const;
};

