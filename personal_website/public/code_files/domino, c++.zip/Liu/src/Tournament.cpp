#include <regex>
#include "Tournament.h"


Tournament::Tournament(void)
{
	playerWins = 0;
	cpuWins = 0;
}

void Tournament::startTour() {
	/*
	ifstream::is_open()
	loadGame()
	Game::newGame()
	Game::shuffleGame()
	ifstream::close()
	Game::startGame()
	saveGame()
	roundWinner()
	keepPlaying()
	*/
	char input;
	//checks to see how game exited
	string endOfGame;
	//checks to see if save was sucessful
	int saveTry;
	//user inputs filename of savefile
	string inputFileName;
	ifstream saveFile;
	//can open the file
	bool canOpen;

	cout << "Welcome to the Domino game!" << endl << endl;

	do {
		cout << "[N]ew Game\n[L]oad?" << endl;
		cin >> input;
	} while (input != 'N' && input != 'L');

	if (input == 'L') {
		do {
			cout << "Please enter the file name: ";
			cin >> inputFileName;
			ifstream saveFile((inputFileName));
			canOpen = saveFile.is_open();
			if (!canOpen) {
				cout << "Unable to open file!" << endl;
			}
			else {
				//loadState holds value if game loaded in properly
				int loadState = loadGame(inputFileName);
				//if no stacks are found, begin new game
				if (loadState == 0) {
					game1.newGame();
				}
				//if stacks are found, but no hand, shuffle and set start values
				else if (loadState == -2) {
					game1.shuffleGame();
				}
				//if translation failed
				else if (loadState == -1) {
					cout << "Failed to Load!" << endl;
					return;
				}
				else {
					cout << "Game state loaded!" << endl;
				}
			}
		} while (!canOpen);
		saveFile.close();
	}
	else {
		game1.newGame();
	}
	do {
		//checks to see how game exited
		endOfGame = game1.startGame();
		//checks to see if user asked to save
		if (endOfGame == "S") {
			saveTry = saveGame();
			if (saveTry == -1) {
				cout << "Failed to Save..." << endl;
			}
			exit;
		}
		//updates the winner of the round
		roundWinner(endOfGame);
		if (endOfGame == "CPU") {
			cout << "Computer Wins! \n";
		}
		else if (endOfGame == "player") {
			cout << "You Win! \n";
		}
		else if (endOfGame == "draw") {
			cout << "Draw! \n";
		}
		//prompt user for input until input is Y or N
		do {
			cout << "Rounds computer won: " << cpuWins << endl;
			cout << "Rounds you won: " << playerWins << endl;
			cout << "Play again? (Y/N)" << endl;
			cin >> input;
		} while (input != 'Y' && input != 'N');
		//if input is Y, set up a new game
		keepPlaying(input);
		//otherwise, exit the function
	} while (input != 'N');


}

void Tournament::keepPlaying (char input) {
	//newGame()
	if (input == 'Y') {
		game1.newGame();
	}
}

string Tournament::endOfTour () {
	if (playerWins > cpuWins) {
		return "You win the Tournament!";
	}
	if (playerWins < cpuWins) {
		return "Computer wins the Tournament.";
	}
	else {
		return "The Tournament was a Draw.";
	}
}


Tournament::~Tournament(void)
{
	endOfTour();
}

int Tournament::saveGame(){
	/*
		ifstream::is_open()
		fstream::close()
		Game::getBoard()
		BoardView::getCPUBoardString()
		Game::getComputer()
		Player::getBoneyard
		Player::getHand()
		Player::getScore()
		Game::getHuman()
		BoardView::getPlayerBoardString()
		Game::getTurn()
	*/
	char input;
	string fileName;

	do {
		input = 'Y';
		//prompts user for filename to save to
		cout << "Please enter a file name to save to: \n";
		cin >> fileName;
		//automatically appends .txt file extension
		fileName += ".txt";
		//if file already exists, do not save over it
		ifstream tryFile(fileName);
		if (tryFile.is_open()) {
			do {
				//prompt user for overwrite
				cout << "File already exists! Overwrite? (Y/N)" << endl;
				cin >> input;
			} while (input != 'Y' && input != 'N');
		}
		tryFile.close();
		//if user inputs N to overwrite, ask for new save file name
	} while (input == 'N');
	if (input == 'Y') {
		//opens the file and prints the save data to it
		ofstream saveFile(fileName);
		saveFile << "Computer: " << endl;
		saveFile << "\t" << game1.getBoard()->getStringCPUBoard() << endl;
		saveFile << "\tBoneyard: " << game1.getComputer()->getBoneyard() << endl;
		saveFile << "\t" << game1.getComputer()->getHand() << endl;
		saveFile << "\tScore: " << game1.getComputer()->getScore() << endl;
		saveFile << "\tRounds Won: " << cpuWins << endl;
		saveFile << endl;
		saveFile << "Human: " << endl;
		saveFile << "\t" << game1.getBoard()->getStringPlayerBoard() << endl;
		saveFile << "\tBoneyard: " << game1.getHuman()->getBoneyard() << endl;
		saveFile << "\t" << game1.getHuman()->getHand() << endl;
		saveFile << "\tScore: " << game1.getHuman()->getScore() << endl;
		saveFile << "\tRounds Won: " << playerWins << endl;
		saveFile << "Turn: ";
		if (game1.getTurn() == 0) {
			saveFile << "Computer";
		}
		else {
			saveFile << "Human";
		}
		saveFile.close();

		exit(0);
	}
	return -1;
}

void Tournament::roundWinner(string input) {
	if (input == "CPU") {
		cpuWins++;
	}
	if (input == "player") {
		playerWins++;
	}
}

int Tournament::loadGame(string filename) {
	/*
		ifstream::is_open()
		ifstream::eof()
		istream::getline()
		regex::rege_replace()
		string::erase()
		string::begin()
		Game::getBoard()
		Board::setField()
		Game::setHands();
		Game::getComputer()
		Player::setBoneyard()
		Player:setHand()
		Player::setScore()
		Game::setHuman()
		Game::setTurn()
		ifstream:close()
	*/
	const int MAX_DOMINOS = 28;
	ifstream loadFile((filename));
	string temp;
	regex stacks ("\\sStacks: ");
	regex boneyard("\\sBoneyard: ");
	regex hand ("\\sHand: ");
	regex score ("\\sScore: ");
	regex round ("\\sRounds Won: ");
	regex turn("Turn: ");
	const string emptyStr = "";
	Domino domArr[MAX_DOMINOS];
	//iterates through domArr
	int arrCount = 0;

	if (loadFile.is_open()) {
		while (!loadFile.eof()) {
			//moves over "Computer:"
			getline(loadFile, temp);
			//gets next line to create field: STACKS
			getline(loadFile, temp);
			//passes over the identifying text
			temp = regex_replace(temp, stacks, emptyStr);
			//gets rid of spaces before the actual data
			while (temp[0] == ' ') {
				temp.erase(temp.begin());
			}
			//parses the remaining string data
			//the count advances by 4  because the start of each domino value in the string is 4 characters apart
			//the first character is color, the second is pip1, the third is pip2, the forth is a space
			for (int count = 0; count < temp.size(); count += 4) {
				domArr[arrCount].setColor(temp[count]);
				domArr[arrCount].setPip1(temp[count + 1] - 48);
				domArr[arrCount].setPip2(temp[count + 2] - 48);
				arrCount++;
			}
			//if no STACKS placed
			if (arrCount == 0) {
				//0 indicates new game needed
				game1.setHands(0);
				return 0;
			}
			//sets the STACKS
			game1.getBoard()->setField(domArr, arrCount, 0);

			//reset iterator
			arrCount = 0;

			//gets next line to create field: BONEYARD
			getline(loadFile, temp);
			//passes over the identifying text
			temp = regex_replace(temp, boneyard, emptyStr);
			while (temp[0] == ' ') {
				temp.erase(temp.begin());
			}
			//parses the remaining string data
			//the count advances by 4  because the start of each domino value in the string is 4 characters apart
			//the first character is color, the second is pip1, the third is pip2, the forth is a space
			for (int count = 0; count < temp.size(); count += 4) {
				domArr[arrCount].setColor(temp[count]);
				domArr[arrCount].setPip1(temp[count + 1] - 48);
				domArr[arrCount].setPip2(temp[count + 2] - 48);
				arrCount++;
			}
			int loadstate = 0;
			//switch case determines number of hands based on the number of tiles left in the boneyard
			switch (arrCount) {
			case 16:
				game1.setHands(1);
				break;
			case 10:
				game1.setHands(2);
				break;
			case 4:
				game1.setHands(3);
				break;
			case 0:
				game1.setHands(4);
				break;
			default:
				game1.setHands(0);
				loadstate = -1;
				break;
			}

			//sets the BONEYARD
			game1.getComputer()->setBoneyard(domArr, arrCount);

			//reset iterator
			arrCount = 0;

			//gets next line to create field: HAND
			getline(loadFile, temp);
			//passes over the identifying text
			temp = regex_replace(temp, hand, emptyStr);
			while (temp[0] == ' ') {
				temp.erase(temp.begin());
			}
			//parses the remaining string data
			//the count advances by 4  because the start of each domino value in the string is 4 characters apart
			//the first character is color, the second is pip1, the third is pip2, the forth is a space
			for (int count = 0; count < temp.size(); count += 4) {
				domArr[arrCount].setColor(temp[count]);
				domArr[arrCount].setPip1(temp[count + 1] - 48);
				domArr[arrCount].setPip2(temp[count + 2] - 48);
				arrCount++;
			}
			if (arrCount != 0) {
				game1.getComputer()->setHand(domArr, arrCount);
			}

			//reset iterator
			arrCount = 0;

			//gets next line to create field: SCORE
			getline(loadFile, temp);
			//passes over the identifying text
			temp = regex_replace(temp, score, emptyStr);
			while (temp[0] == ' ') {
				temp.erase(temp.begin());
			}
			//sets the score
			game1.getComputer()->setScore(stoi(temp));

			//gets next line to create field: ROUNDS WON
			getline(loadFile, temp);
			//passes over the identifying text
			temp = regex_replace(temp, round, emptyStr);
			while (temp[0] == ' ') {
				temp.erase(temp.begin());
			}
			cpuWins = stoi(temp);

			//---------------------------------------------------------------Begin Loading Human Player
			//moves over empty line
			getline(loadFile, temp);
			//moves over "Human:"
			getline(loadFile, temp);
			//gets next line to create field: STACKS
			getline(loadFile, temp);
			//passes over the identifying text
			temp = regex_replace(temp, stacks, emptyStr);
			while (temp[0] == ' ') {
				temp.erase(temp.begin());
			}
			//parses the remaining string data
			//the count advances by 4  because the start of each domino value in the string is 4 characters apart
			//the first character is color, the second is pip1, the third is pip2, the forth is a space
			for (int count = 0; count < temp.size(); count += 4) {
				domArr[arrCount+6].setColor(temp[count]);
				domArr[arrCount+6].setPip1(temp[count + 1] - 48);
				domArr[arrCount+6].setPip2(temp[count + 2] - 48);
				arrCount++;
			}
			//sets the STACKS
			game1.getBoard()->setField(domArr, arrCount, 6);

			//reset iterator
			arrCount = 0;

			//gets next line to create field: BONEYARD
			getline(loadFile, temp);
			//passes over the identifying text
			temp = regex_replace(temp, boneyard, emptyStr);
			while (temp[0] == ' ') {
				temp.erase(temp.begin());
			}
			//parses the remaining string data
			//the count advances by 4  because the start of each domino value in the string is 4 characters apart
			//the first character is color, the second is pip1, the third is pip2, the forth is a space
			for (int count = 0; count < temp.size(); count += 4) {
				domArr[arrCount].setColor(temp[count]);
				domArr[arrCount].setPip1(temp[count + 1] - 48);
				domArr[arrCount].setPip2(temp[count + 2] - 48);
				arrCount++;
			}
			//sets the BONEYARD
			game1.getHuman()->setBoneyard(domArr, arrCount);

			//reset iterator
			arrCount = 0;

			//gets next line to create field: HAND
			getline(loadFile, temp);
			//passes over the identifying text
			temp = regex_replace(temp, hand, emptyStr);
			while (temp[0] == ' ') {
				temp.erase(temp.begin()) ;
			}
			//parses the remaining string data
			//the count advances by 4  because the start of each domino value in the string is 4 characters apart
			//the first character is color, the second is pip1, the third is pip2, the forth is a space
			for (int count = 0; count < temp.size(); count += 4) {
				domArr[arrCount].setColor(temp[count]);
				domArr[arrCount].setPip1(temp[count + 1] - 48);
				domArr[arrCount].setPip2(temp[count + 2] - 48);
				arrCount++;
			}
			if (arrCount != 0) {
				game1.getHuman()->setHand(domArr, arrCount);
			}

			//reset iterator
			arrCount = 0;

			//gets next line to create field: SCORE
			getline(loadFile, temp);
			//passes over the identifying text
			temp = regex_replace(temp, score, emptyStr);
			while (temp[0] == ' ') {
				temp.erase(temp.begin());
			}
			//sets the score
			game1.getHuman()->setScore(stoi(temp));

			//gets next line to create field: ROUNDS WON
			getline(loadFile, temp);
			//passes over the identifying text
			temp = regex_replace(temp, round, emptyStr);
			while (temp[0] == ' ') {
				temp.erase(temp.begin());
			}
			playerWins = stoi(temp);

			//moves over empty line
			getline(loadFile, temp);
			//reads TURN
			getline(loadFile, temp);
			temp = regex_replace(temp, turn, emptyStr);
			while (temp[0] == ' ') {
				temp.erase(temp.begin());
			}
			//reads the string, and sets the turn value to that player's turn
			if (temp == "Computer") {
				game1.setTurn(0);
			}
			else {
				game1.setTurn(1);
			}
			if (loadstate == -1) {
				//returns that the file did not have values for the hands, and the turn is undetermined
				loadFile.close();
				return -2;
			}
			loadFile.close();
			return 1;
		}
	}
	else {
		//-1 indicates failed load
		loadFile.close();
		return -1;
	}
}
