#pragma once
#include <string>
#include <iostream>
using namespace std;

class Domino {
public:
	//default constructor
	Domino ();
	//constructor
	Domino (int val1, int val2, char player);
	//desturctor
	~Domino();
	/* *********************************************************************
	Function Name: getValue
	Purpose: Gets the total of the pips on a domino
	Parameters: none
	Return Value: The total of the pips on the domino, as integer
	Assistance Received: none
	********************************************************************* */
	int getValue () const; 
	/* *********************************************************************
	Function Name: getDouble
	Purpose: Determines if the two sides of the domino are equal
	Parameters: none
	Return Value: A boolean that is true if the domino is a double and 
		false if it is not
	Assistance Received: none
	********************************************************************* */ 
	bool getDouble () const;
	/* *********************************************************************
	Function Name: getPip1
	Purpose: Gets the value of the 1st side of a domino
	Parameters: none
	Return Value: The integer value of the 1st side of a domino
	Assistance Received: none
	********************************************************************* */ 
	int getPip1 () const;
	/* *********************************************************************
	Function Name: getPip2
	Purpose: Gets the value of the 2nd side of a domino
	Parameters: none
	Return Value: The integer value of the 2nd side of a domino
	Assistance Received: none
	********************************************************************* */ 
	int getPip2 () const;
	
	/* *********************************************************************
	Function Name: getColor
	Purpose: Gets the color of the domino tile
	Parameters: none
	Return Value: A character, B indicating black, and W indicating white
	Assistance Received: none
	********************************************************************* */ 
	char getColor () const;
	/* *********************************************************************
	Function Name: getDomino
	Purpose: Gets the domino in the form 'c(olor) xy'
	Parameters: none
	Return Value: A string that contains the domino in the form 'c(olor) xy'
	Assistance Received: none
	********************************************************************* */ 
	string getDomino () const;

	/* *********************************************************************
	Function Name: setPip1
	Purpose: mutates the value of pip1
	Parameters: integer input, the value pip1 will be set to 
	Return Value: 0 if set was successful, -1 if not
	Assistance Received: none
	********************************************************************* */
	int setPip1(int input);

	/* *********************************************************************
	Function Name: setPip2
	Purpose: mutates the value of pip2
	Parameters: integer input, the value pip2 will be set to
	Return Value: 0 if set was successful, -1 if not
	Assistance Received: none
	********************************************************************* */
	int setPip2(int input);

	/* *********************************************************************
	Function Name: setColor
	Purpose: mutates the value of color
	Parameters: character input, the value color will be set to
	Return Value: 0 if set was successful, -1 if not
	Assistance Received: none
	********************************************************************* */
	int setColor(char input);


	/* *********************************************************************
	Function Name: copy
	Purpose: copies pip1, pip2, and color of another domino
	Parameters: Domino input, domino that whose values will be copied
	Return Value: none
	Assistance Received: none
	********************************************************************* */
	void copy(Domino input);


private:
	//records the color of the tile
	char color;
	//records the value of one side of the domino
	int pip1;
	//records the value of the other side of the domino
	int pip2;
	//records the total of pip1 and pip2
	int value;
	//records whether or not pip1 and pip2 are the same
	bool isDouble;
	//maximum number of pips per one side
	static const int MAX_PIP = 6;
};