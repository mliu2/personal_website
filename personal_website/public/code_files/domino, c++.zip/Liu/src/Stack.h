#pragma once
#include <sstream>
#include <string>
#include <vector>
#include <iterator>
#include "domino.h"

class Stack
{
public:
	
	Stack(void);
	~Stack(void);

	/* *********************************************************************
	Function Name: getSize
	Purpose: gets the size of the Stack
	Parameters: none
	Return Value: size of the Stack object
	Assistance Received: none
	********************************************************************* */
	int getSize() const;
	/* *********************************************************************
	Function Name: getTop
	Purpose: gets the index of the top of the Stack
	Parameters: none
	Return Value: index of the top of the Stack object
	Assistance Received: none
	********************************************************************* */
	int getTop() const;
	/* *********************************************************************
	Function Name: getDomino
	Purpose: gets a Domino at a location
	Parameters: interger input, the index of the Domino to be retreived
	Return Value: Domino at input location
	Assistance Received: none
	********************************************************************* */
	Domino* get(int input);
	/* *********************************************************************
	Function Name: getMax
	Purpose: gets the maximum size of the stack allowed
	Parameters: none
	Return Value: maximum size of the Stack object
	Assistance Received: none
	********************************************************************* */
	int getMax() const;
	/* *********************************************************************
	Function Name: getStack
	Purpose: gets the Stack of Dominoes as a string, separated by spaces
	Parameters: none
	Return Value: string of Dominoes, separated by spaces
	Assistance Received: none
	********************************************************************* */
	string getStack() const;
	/* *********************************************************************
	Function Name: getTopOfStack
	Purpose: gets the Domino at the top of the stack
	Parameters: none
	Return Value: Domino at the top of the stack
	Assistance Received: none
	********************************************************************* */
	Domino getTopOfStack() const;

	/* *********************************************************************
	Function Name: setSize
	Purpose: sets the current size of the stack
	Parameters: integer input that will be the new size of the stack
	Return Value: 0 if the set was successful, otherwise -1
	Assistance Received: none
	********************************************************************* */
	int setSize(int input);
	/* *********************************************************************
	Function Name: copy
	Purpose: copies the values of the dominoes in input stack
	Parameters: Stack input whose dominoes' values will be copied
	Return Value: none
	Assistance Received: none
	********************************************************************* */
	void copy(Stack input);
	/* *********************************************************************
	Function Name: copy
	Purpose: copies the values of the dominoes in an array
	Parameters: Domino Array input, pass by reference, not modified ; size, the size of the input array
	Return Value: none
	Assistance Received: none
	********************************************************************* */
	void copy(Domino input[], int size);
	/* *********************************************************************
	Function Name: remakeStack
	Purpose: Resets the stack to contain a full set of 28 dominoes of one color and shuffles it
	Parameters: character color, which will be the new color of all of the dominoes in the stack
	Return Value: none
	Assistance Received: none
	********************************************************************* */
	void remakeStack(char color);

	/* *********************************************************************
	Function Name: shuffleStack
	Purpose: shuffles the stack of dominoes
	Parameters: none
	Return Value: none
	Assistance Received: none
	********************************************************************* */
	void shuffleStack ();
	/* *********************************************************************
	Function Name: drawFromStack
	Purpose: "Draw" the top domino from the stack, removing it from the stack and decreasing the stack size
	Parameters: none
	Return Value: The domino that was drawn
	Assistance Received: none
	********************************************************************* */
	Domino drawFromStack ();

private:
	//maximum number of pips per side of a domino
	static const int MAX_PIPS = 6;
	//maximum number of tiles in the stack
	static const int MAX_DECK_SIZE = 28;
	//number of tiles in the stack
	int size;
	//array that keeps track of the stack
	Domino deck[MAX_DECK_SIZE];
};

