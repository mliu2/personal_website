#pragma once
#include <string>
#include "domino.h"
using namespace std;

class Board
{
public:
	//default constructor
	Board(void);
	//destructor
	~Board(void);

	/* *********************************************************************
	Function Name: getField
	Purpose: returns the board as an array of dominoes
	Parameters: none
	Return Value: a pointer to the array of dominoes
	Assistance Received: none
	********************************************************************* */
	Domino* getField() const;
	/* *********************************************************************
	Function Name: getScore
	Purpose: gets the score a player would recieve from the current boardstate
	Parameters: character color, indicating which tiles to count
	Return Value: integer score of that player
	Assistance Received: none
	********************************************************************* */
	int getScore(char color) const;

	/* *********************************************************************
	Function Name: SetField
	Purpose: sets the field to an array
	Parameters: Domino array input, passed by value, not modified; integer size
		is the size of the input array; integer start is the index where the array
		start to be read from
	Return Value: none
	Assistance Received: none
	********************************************************************* */
	void setField(Domino input[], int size, int start);

	//copies the field from another board
	void copy(Board input);
	//copies field from an array
	void copy(Domino input[], int size);
	
protected:
	//index in array where the player's tiles start
	static const int PLAYER_TILE_START = 6;
	//maxiumum field size;
	static const int MAX_FIELD_SIZE = 12;
	//array holds the top tile of each stack
	Domino* field;
};

