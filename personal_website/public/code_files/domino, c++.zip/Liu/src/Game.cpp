#include "Game.h"


Game::Game(void)
{
	turn = 0;
	hands =  0;
}


Game::~Game(void)
{
}

void Game::setHands (int input) {
	//validates input
	if (input >= 0 && input <= MAX_HANDS) {
		hands = input;
	}
}
int Game:: getHands () const {
	return hands;
}

void Game::printGameState() {
	/*
		Player::getScore()
		Player::getHand()
	*/
	cout << endl << "=========================================================" << endl;
	cout << "Hands: " << hands << endl;
	//prints the score
	cout << "Score: " << playerC.getScore() << endl;
	//print the board
	cout << table.printBoard();
	//prints the score
	cout << "Score: " << playerH.getScore() << endl;
	//prints the player's hand
	cout << endl;
	playerH.handSort();
	cout << playerH.getHand() << endl;
	cout << "Tile#:  0   1   2   3   4   5" << endl;
}

string Game::getWinner() const {
	//Player::getScore()

	string retStr = "draw";
	//compares scores to see if there is a winner. Otherwise, the default return is "draw"
	if (playerC.getScore() > playerH.getScore()) {
		retStr = "CPU";
	}
	if (playerC.getScore() < playerH.getScore()) {
		retStr = "player";
	}

	return retStr;
}

void Game::newGame() {
	/*
		Player::setScore()
		Board::getField()
		Player::beginStack()
		shuffleGame()
	*/

	playerC.setScore(0);
	playerH.setScore(0);
	//rests hand to 0, will be incremented when game starts
	hands = 0;

	//gets the top 6 dominoes to make the stacks
	playerC.beginStack(table.getField());
	playerH.beginStack(table.getField());
	//prevents draws for who goes first
	shuffleGame();
	
	
	return;
}

string Game::startGame() {
	/*
		Player::getStart()
		Player::getHandSize()
		Player::getPass()
		Player::getScore()
		Player::getColor()
		Board::getScore()
		Player::handScorePenalty()
		Player::setScore()
		Player::emptyHand()
		Player::drawDomino()
		Player::setPass()
		printGameState()
		Board::getField()
		Computer::playCPU()
		Player::thinkCPU()
		std::stoi()
		Player::pass()
		Player::parseStackName()
		Player::placeDomino()
		getWinner()

	*/
	string input;
	//holds "pass" if the player may pass
	string mayPass;
	//holds user input of index of tile in hand
	int tileinput = -1;	

	if (hands == 0) {
		//if the computer's start tile is higher, it goes first
		if (playerC.getStart() > playerH.getStart()) {
			turn = 0;
		}
		//otherwise player goes first
		else {
			turn = 1;
		}

	}

	//loop that contains the game 
	do {
		//if both hands are empty, draw or if both players pass, begin a new hand
		if ((playerC.getHandSize() == 0 && playerH.getHandSize() == 0) || (playerC.getPass() && playerH.getPass())) {
			//tally up scores for previous hand 
			if (hands != 0){
				playerC.setScore(playerC.getScore() + table.getScore(playerC.getColor()) - playerC.handScorePenalty());
				playerH.setScore(playerH.getScore() + table.getScore(playerH.getColor()) - playerH.handScorePenalty());
			}
			//empties both hands
			playerC.emptyHand();
			playerH.emptyHand();

			hands++;
			//break out if max hands exceeded
			if (hands > MAX_HANDS) {
				break;
			}
			cout << "-------------Start hand!--------------" << endl;
			//draws new hand
			playerC.drawDomino();
			playerH.drawDomino();
			//resets pass values for both players
			playerC.setPass(false);
			playerH.setPass(false);

		}
		//if Computer goes first
		if (turn == 0) {
			printGameState();
			cout << "Computer's turn." << endl;
			playerC.handSort();
			playerC.playCPU(table.getField());
			
			//verifies with user
			cout << "Type [S] to save and anything else to continue" << endl;
			cin >> input;
			//allows player to go
			turn = 1;
			//if any point the user inputs "S", break out of the loops and go to the saveGame function call
			if (input == "S") {
				break;
			}
			//if both payer have an empty hand, go to the top of the loop and begin a new hand
			if (playerC.getHandSize() == 0 && playerH.getHandSize() == 0) {
				continue;
			}

			//if both players pass, then to to the top of the loop begin next hand
			if (playerC.getPass() && playerH.getPass()) {
				continue;
			}
		}
		printGameState();

		if (turn == 1) {
			//checks if move is legal
			int legalMove = -1;
			do {
				cout << "Your turn." << endl;
				cout << "Please play, or type [S]ave, or [H]elp" << endl;
				//if no tiles can be played, allows player to pass
				mayPass = " ";
				mayPass = playerH.thinkCPU(table.getField(), playerC.getColor(), false);
				if ( mayPass == "pass") {
					cout << "You may pass. Type [pass] to pass.\n";
				}

				//user prompt until inputs are valid
				do {
					cout << "Choose a tile #: ";
					cin >> input;
					//if player asks for help, use the computer's algorithm to find moves
					if (input == "H") {
						playerH.thinkCPU(table.getField(), playerC.getColor(), true);
					}
					//if the input tile index is valid, go out of loop to ask for stack name
					if (input >= "0" && input <= "5") {
						//converts tile input from string to integer
						tileinput = stoi(input);
						break;
					}
					if (input == "pass") {
						//if player tries to pass but does has moves left, do not allow passing
						if (mayPass != "pass") {
							cout << "You have moves left!\n";
						}
						//if the player has no moves left, allow passing
						else {
							break;
						}
					}
					//if the user wishes to save break out of the loop that askes for input
				} while (input != "S");
				//if any point the user inputs "S", break out of the loops and go to the saveGame function call
				if (input == "S") {
					break;
				}
				//if the "pass" was validated previously, it will come down here, call the pass function, and stop asking for input
				if (input == "pass") {
					cout << "You " << playerH.pass() << endl;
					break;
				}
				//askes user 
				cout << "Choose a location: ";
				cin >> input;
				//if any point the user inputs "S", break out of the loops and go to the saveGame function call
				if (input == "S") {
					break;
				}

				//checks if move is legal
				legalMove = playerH.placeDomino(tileinput, playerH.parseStackName(input), table.getField());
				if (legalMove != -1) {
					cout << "Placing tile at location " + input << endl;
					//table.setField(playerH.getField(), 0);
				}
				else {
					cout << "Illegal Move" << endl;
				}
			} while (legalMove == -1);
			//ensures CPU can take next turn
			turn = 0;
			//if both players pass, then next hand
			if (playerC.getPass() && playerH.getPass()) {
				continue;
			}
		}
		//if any point the user inputs "S", break out of the loops and go to the saveGame function call
		//if the game exceeds the maximum number of hands, stop playing 
	} while (input != "S" && hands <= MAX_HANDS);
	//if user did not ask to save, this means the game ended, and scores should be compared to find the winner
	if (input != "S") {
		cout << "Computer Score: " << playerC.getScore() << endl;
		cout << "Your Score: " << playerH.getScore() << endl;
		//this function compares scores
		return getWinner();
	}
	else {
		//otherwise pass up "S", which will be read by the startTour function
		return "S";
	}
}

void Game::setTurn(int input) {
	//validates input
	if (input == 0 || input == 1) {
		turn = input;
	}
}

BoardView* Game::getBoard(){
	return &table;
}

Human* Game::getHuman(){
	return &playerH;
}

Computer* Game::getComputer(){
	return &playerC;
}

int Game::getTurn() const {
	return turn;
}

void Game::shuffleGame() {
	/*
		Player::shuffleDeck()
		Player::setStart()
		Player::getStart()
	*/

	do {
		//shuffles both player's boneyards
		playerC.shuffleDeck();
		playerH.shuffleDeck();
		//sets the start tile for players
		playerC.setStart();
		playerH.setStart();
		//this will continue until the start values are not equal
	} while (playerC.getStart() == playerH.getStart());

	cout << "Computer's tile value: " << playerC.getStart() << endl;
	cout << "Humans's tile value: " << playerH.getStart() << endl;
}