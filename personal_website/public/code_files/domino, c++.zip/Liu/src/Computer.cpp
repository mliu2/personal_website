#include "Computer.h"


Computer::Computer(void)
{
	boneyard.remakeStack(COLOR);
}


Computer::~Computer(void)
{
}


char Computer::getColor() const {
	return COLOR;
}

void Computer::remake() {
	//Stack::remakeStake()

	boneyard.remakeStack(COLOR);
}

void Computer::beginStack(Domino* field) {
	/*
		Stack::drawFromStack()
		Domino::copy()
		setStart()
	*/

	//draws 6 tiles from each boneyard to use as the board
	for (int count = 0; count < PLAYER_TILE_START; count++) {
		field[count].copy(boneyard.drawFromStack());
	}
	setStart();
}

void Computer::playCPU(Domino* field) {
	/*
		Player::thinkCPU()
		Player::pass()
		Player::parseStackName()
		Player::placeDomino()
	*/

	//gets the command from the thinkCPU algorithm to be parsed
	string command = thinkCPU(field, ENEMY, true);
	int stackNumber;
	int tileIndexInHand;

	//passes if ai recommends pass
	if (command == "pass") {
		pass();
		return;
	}
	//parses part of the command string into a location
	stackNumber = parseStackName(command);

	//4th char of input is tile in hand
	tileIndexInHand = command[3]-48;
	//plays the domino
	placeDomino(tileIndexInHand, stackNumber, field);

}