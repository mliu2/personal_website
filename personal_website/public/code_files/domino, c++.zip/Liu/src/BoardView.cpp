#include "BoardView.h"


BoardView::BoardView()
{
}


BoardView::~BoardView()
{
}

string BoardView::printBoard() const {
	/*
		 getStringCPUBoard()
		 getStringPlayerBoard()
	*/
	string retStr;
	//returns the string with both sides of the board with labels under them
	retStr = getStringCPUBoard() + "\n \tW1  W2  W3  W4  W5  W6\n" + getStringPlayerBoard() + "\n \tB1  B2  B3  B4  B5  B6\n";
	return retStr;
}

string BoardView::getStringCPUBoard(void) const{
	//Domino::getDomino()

	string boardState = "Stacks: ";
	//gets every domino on the computer's side of the board
	for (int count = 0; count < PLAYER_TILE_START; count++) {
		boardState = boardState + field[count].getDomino() + " ";
	}

	return boardState;
}

string BoardView::getStringPlayerBoard(void) const{
	//Domino::getDomino()

	string boardState = "Stacks: ";
	//gets every domino on the human's side of the board
	for (int count = PLAYER_TILE_START; count < MAX_FIELD_SIZE; count++) {
		boardState = boardState + field[count].getDomino() + " ";
	}

	return boardState;
}