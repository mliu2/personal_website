var express = require('express');
var mongodb = require('mongodb')
var MongoClient = mongodb.MongoClient;
var url = 'mongodb://localhost:27017/test';
var geocoderProvider = 'google';
var httpAdapter = 'http';
var geocoder = require('node-geocoder')(geocoderProvider, httpAdapter);
var router = express.Router();

function restrict(req, res, next){
  if ( req.user ) {
		next();
	}
	else {
		res.redirect("/login");
	}
}

/* GET home page. */
router.get('/', function(req, res, next) {
  var logged_in = false;
  if (req.user){
    logged_in = true;
  }
  res.render('form', {login: logged_in});
});
router.get('/mailer', function(req, res, next) {
  var logged_in = false;
  if (req.user){
    logged_in = true;
  }
	res.render('form', {login: logged_in});
});

//GET contacts page
router.get('/contacts', restrict, function(req, res, next) {
  MongoClient.connect(url, function(err, db){
    if (err){
      console.log(err);
    } else {
      var collection = db.collection('contacts');
      collection.find().toArray(function (err, result) {
        if (err){
          console.log(err);
        } else {
          res.render('table', {list: result, login: true});
          db.close();
      }
    });
  }
});
});
//thank you page
router.post('/thank', function(req, res, next) {
  var body = req.body;
  MongoClient.connect(url, function(err, db){
    if (err){
      console.log(err);
    } else {
      var collection = db.collection('contacts');
      var addr = body.street + body.state + body.zip;
      geocoder.geocode( addr, function (err, res){
        body.longitude = res[0]['longitude'];
        body.latitude = res[0]['latitude'];
        collection.insert(body);
        db.close();
      });
    }
  });
  var logged_in = false;
  if (req.user){
    logged_in = true;
  }
  res.render('thank', {login: logged_in});
});
//when deleted, return to contact page
router.post('/del', function(req, res, next) {
  MongoClient.connect(url, function(err, db){
    if (err){
      console.log(err);
    } else {
      var collection = db.collection('contacts');
      collection.deleteOne({'_id': new mongodb.ObjectId(req.body.del)}, function(){
          db.close();
          res.end();
      });
    }
  });
});
//returns Contact info to contacts page
router.get('/getid/:id(\\w+)/', function(req, res, next){
  MongoClient.connect(url, function(err, db){
    if (err){
      console.log(err);
    } else {
      var collection = db.collection('contacts');
      collection.findOne({'_id': new mongodb.ObjectId(req.params.id)}, function(err,data){
        if (err){
          console.log(err);
        } else{
          db.close();
          console.log(data);
          res.end(JSON.stringify(data));
        }
      });
    }
  });
});
//handles incoming edits from /contacts
router.post('/make',function(req, res, next) {
  var body = req.body;
  MongoClient.connect(url, function(err, db){
    if (err){
      console.log(err);
    } else {
      var collection = db.collection('contacts');
      //if id is set, edit existing record
      if (body.id){

        var addr = body.street + body.state + body.zip;
        geocoder.geocode( addr, function (err, result){
          body.longitude = result[0]['longitude'];
          body.latitude = result[0]['latitude'];
          collection.update({'_id': new mongodb.ObjectId(body.id)}, body, function(err){
            if (err){
              console.log(err);
            }
            else{
              db.close();
              res.redirect('/contacts');
            }
          });
        });
      }
      //if id is not set, make new record
      else{
        var addr = body.street + body.state + body.zip;
        geocoder.geocode( addr, function (err, result){
          body.longitude = result[0]['longitude'];
          body.latitude = result[0]['latitude'];
          collection.insert(body);
          db.close();
          res.redirect('/contacts');
        });
      }

    }
  });

});

module.exports = router;
