package mingliu.buildupdominoes;

public class Board {
	protected static final int MAX_STACKS = 12;
	protected static final int PLAYER_TILE_START = 6;
	protected Domino[] stacks;
	
	public Board() {
		stacks = new Domino[MAX_STACKS];
	}
	/**********************************************************************
	Function Name: getStacks
	Purpose: returns the board as an array of dominoes
	@param Parameters: none
	@return Return Value: an array of dominoes
	Assistance Received: none
	********************************************************************* */
	public Domino[] getStacks() {
		return stacks;
	}
	/**********************************************************************
	Function Name: getScore
	Purpose: gets the score a player would recieve from the current boardstate
	@param Parameters: character color, indicating which tiles to count
	@return Return Value: integer score of that player from the current tiles on the stack
	Assistance Received: none
	********************************************************************* */
	public int getScore(char color) {
		int score = 0;
		for (int count = 0; count < MAX_STACKS; count++) {
			if (stacks[count].getColor() == color) {
				score += stacks[count].getValue();
			}
		}
		return score;
	}
	/**********************************************************************
	Function Name: getStringCPUBoard
	Purpose: returns the computer's side of the board as a string 
	@param Parameters: none
	@return Return Value: a string with "Stack: " and then dominoes separated by spaces
	Assistance Received: none
	********************************************************************* */
	public String getStringCPUBoard() {
		String retStr = new String();
		for (int count = 0; count < PLAYER_TILE_START; count++) {
			retStr += stacks[count].getString() + " ";
		}
		return retStr;
	}
	/**********************************************************************
	Function Name: getStringHumanBoard
	Purpose: returns the human's side of the board as a string
	@param Parameters: none
	@return Return Value: a string with "Stack: " and then dominoes separated by spaces
	Assistance Received: none
	********************************************************************* */
	public String getStringHumanBoard() {
		String retStr = new String();
		for (int count = PLAYER_TILE_START; count < MAX_STACKS; count++) {
			retStr += stacks[count].getString() + " ";
		}
		return retStr;
	}
	/**********************************************************************
	Function Name: setField
	Purpose: sets the field to an array
	@param Parameters: Domino array input, passed by pointer, not modified; integer size
		is the size of the input array; integer start is the index where the array
		start to be read from
	@return Return Value: none
	Assistance Received: none
	********************************************************************* */
	public void setField(Domino input[], int size, int start) {
		/**
		 * Domino::copy()
		 * 
		 * copies up to size or until the max field size is reached number of
		 * dominoes from input at index start to the same index on the board
		 */
		for (int count = start; count < MAX_STACKS; count++) {
			if ((count - start) < size) {
				stacks[count].copy(input[count - start]);
			}
		}
	}

	/**********************************************************************
	Function Name: indexToStack
	Purpose: Converts an numerical index to the name of the stack
	@param Parameters: Integer to the index of of the stack on the Board
	@return Return Value: A String for the name of the stack
	Assistance Received: none
	********************************************************************* */
	public String indexToStack(int index) {
		if (index < Board.PLAYER_TILE_START) {
			return "W" + Integer.toString(index + 1);
		} else {
			return "B" + Integer.toString(index - Board.PLAYER_TILE_START + 1);
		}
	}

	

}
