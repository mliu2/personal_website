package mingliu.buildupdominoes;


public class Domino {
	protected static final int MIN_PIP = 0;
	protected static final int MAX_PIP = 6;
	private char color;
	private int pip1;
	private int pip2;
	
	/**default constructor*/
	public Domino () {
		color = 'E';
		pip1 = 0;
		pip2 = 0;
	}
	/**constructor */
	public Domino (char inputColor, int aPip, int bPip) {
		color = inputColor;
		pip1 = aPip;
		pip2 = bPip;
	}
	/**constructor from string*/
	public Domino (String input){
		color = input.charAt(0);
		pip1 = Character.getNumericValue(input.charAt(1));
		pip2 = Character.getNumericValue(input.charAt(2));
	}
	/**copy constructor*/
	public Domino (Domino input){
		color = input.color;
		pip1 = input.pip1;
		pip2 = input.pip2;
	}
	/**GETers*/
	/**********************************************************************
	Function Name: getColor
	Purpose: Gets the color of the domino tile
	@param Parameters: none
	@return Return Value: A character, B indicating black, and W indicating white, E indicating error
	Assistance Received: none
	********************************************************************* */ 
	public char getColor () {
		return color;
	}
	/**********************************************************************
	Function Name: getPip1
	Purpose: Gets the value of the 1st side of a domino
	@param Parameters: none
	@return Return Value: The integer value of the 1st side of a domino
	Assistance Received: none
	********************************************************************* */ 
	public int getPip1() {
		return pip1;
	}
	/**********************************************************************
	Function Name: getPip2
	Purpose: Gets the value of the 2nd side of a domino
	@param Parameters: none
	@return Return Value: The integer value of the 2nd side of a domino
	Assistance Received: none
	********************************************************************* */ 
	public int getPip2() {
		return pip2;
	}
	/**********************************************************************
	Function Name: getValue
	Purpose: Gets the total of the pips on a domino
	@param Parameters: none
	@return Return Value: The total of the pips on the domino, as integer
	Assistance Received: none
	********************************************************************* */
	public int getValue() {
		return pip1+pip2;
	}
	/**********************************************************************
	Function Name: getString
	Purpose: Gets the domino in the form 'c(olor) xy'
	@param Parameters: none
	@return Return Value: A string that contains the domino in the form 'c(olor) xy'
	Assistance Received: none
	********************************************************************* */ 
	public String getString() {
		String str = new String();
		return str+color+Integer.toString(pip1)+Integer.toString(pip2);
	}
	/**********************************************************************
	Function Name: getDouble
	Purpose: Determines if the two sides of the domino are equal
	@param Parameters: none
	@return Return Value: A boolean that is true if the domino is a double and 
		false if it is not
	Assistance Received: none
	********************************************************************* */ 
	public boolean getDouble() {
		if (pip1 == pip2) {
			return true;
		}
		else {
			return false;
		}
	}
	/**********************************************************************
	Function Name: getDomino
	Purpose: Gets the domino in the form 'c(olor) xy'
	@param Parameters: none
	@return Return Value: A string that contains ASCII domino
	Assistance Received: none
	********************************************************************* */ 
	public String getDomino() {
		String str = new String();
		switch (pip1) {
		case 1: str = str + "\n"+"  *  \n";
		break;
		case 2: str = str + "    *\n\n"+"*    ";
		break;
		case 3: str = str + "    *\n"+"  *  \n"+"*    ";
		break;
		case 4: str = str + "*   *\n\n"+"*   *";
		break;
		case 5: str = str + "*   *\n"+ "  *  \n"+"*   *";
		break;
		case 6: str = str + "* * *\n\n"+"* * *";
		break;
		case 0: str = str + "\n\n";
		break;
		}
		str = str + "\n-----\n";
		switch (pip2) {
		case 1: str = str + "\n"+"  *  \n";
		break;
		case 2: str = str + "    *\n\n"+"*    ";
		break;
		case 3: str = str + "    *\n"+"  *  \n"+"*    ";
		break;
		case 4: str = str + "*   *\n\n"+"*   *";
		break;
		case 5: str = str + "*   *\n"+ "  *  \n"+"*   *";
		break;
		case 6: str = str + "* * *\n\n"+"* * *";
		break;
		case 0: str = str + "\n\n";
		break;
		}
		
		return str;
	}
	/**SETers*/
	/**********************************************************************
	Function Name: setColor
	Purpose: mutates the value of color
	@param Parameters: character input, the value color will be set to
	@return Return Value: 0 if set was successful, -1 if not
	Assistance Received: none
	********************************************************************* */
	public void setColor(char input){
		if ( input == 'E' || input == 'W' || input == 'B'){
			color = input;
		}
	}
	/**********************************************************************
	Function Name: setPip1
	Purpose: mutates the value of pip1
	@param Parameters: integer input, the value pip1 will be set to 
	@return Return Value: 0 if set was successful, -1 if not
	Assistance Received: none
	********************************************************************* */
	public void setPip1(int input) {
		if (input >= MIN_PIP && input <= MAX_PIP){
			pip1 = input;
		}
	}
	/**********************************************************************
	Function Name: setPip2
	Purpose: mutates the value of pip2
	@param Parameters: integer input, the value pip2 will be set to
	@return Return Value: 0 if set was successful, -1 if not
	Assistance Received: none
	********************************************************************* */
	public void setPip2(int input) {
		if (input >= MIN_PIP && input <= MAX_PIP){
			pip2 = input;
		}
	}
	/**********************************************************************
	Function Name: copy
	Purpose: copies pip1, pip2, and color of another domino
	@param Parameters: Domino input, domino that whose values will be copied
	@return Return Value: none
	Assistance Received: none
	********************************************************************* */
	public void copy(Domino source) {
		color = source.color;
		pip1 = source.pip1;
		pip2 = source.pip2;
	}
	
	
	
	
}

