package mingliu.buildupdominoes;

import java.io.OutputStreamWriter;

import de.greenrobot.event.EventBus;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class SaveActivity extends Activity {
	protected final String ERROR = "Error saving file.";
	protected final String SAVED = "File Saved!";
	protected Tournament tournament;
	protected String filename;
	private EditText nEdit;

	/**********************************************************************
	Function Name: onCreate
	Purpose: sets the view for the Saving UI
	@param Parameters: Bundle
	@return Return Value: none
	Assistance Received: none
	********************************************************************* */
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		/**
		 * EventBus::getDefault()::removeStickyEven()
		 * View::findViewByID()
		 */
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_save);
		tournament = (Tournament) EventBus.getDefault().removeStickyEvent(
				Tournament.class);
		nEdit = (EditText) findViewById(R.id.editText1);
	}
	/**********************************************************************
	Function Name: respond
	Purpose: responds to button by save to that file
	@param Parameters: View object being responded to 
	@return Return Value: none
	Assistance Received: none
	********************************************************************* */
	public void respond(View view) {
		/**
		 * View::getText()
		 * OutputStreamWriter::write()
		 * View::findViewById()
		 * View::setText()
		 * OutputStreamWriter::close()
		 * Activity::startActivty()
		 */
		filename = nEdit.getText().toString();
		try {
			OutputStreamWriter output = new OutputStreamWriter(openFileOutput(
					filename, Context.MODE_PRIVATE));
			output.write(tournament.saveGame());
			((TextView) findViewById(R.id.Msg)).setText(SAVED);
			output.close();
			Intent intent = new Intent(this, MainActivity.class);
			startActivity(intent);
		} catch (Exception e) {
			((TextView) findViewById(R.id.Msg)).setText(ERROR);
		}
	}

	
}
