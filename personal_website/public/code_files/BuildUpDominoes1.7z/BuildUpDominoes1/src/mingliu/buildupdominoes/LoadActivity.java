package mingliu.buildupdominoes;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.InputStreamReader;

import de.greenrobot.event.EventBus;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class LoadActivity extends Activity {
	protected final String ERROR = "File not found.";
	protected final String LOAD = "File Loaded!";
	protected Tournament tournament;
	
	/**********************************************************************
	Function Name: onCreate
	Purpose: retrieves Tournament from EventBus when Load begins
	@param Parameters: Bundle
	@return Return Value: none
	Assistance Received: none
	********************************************************************* */
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		/**
		 * EventBus::getDefault()::removeStickyEven()
		 */
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_load);
		tournament = (Tournament) EventBus.getDefault().removeStickyEvent(
				Tournament.class);
	}
	/**********************************************************************
	Function Name: respond
	Purpose: responds to  button by loading that file
	@param Parameters: View object being responded to 
	@return Return Value: none
	Assistance Received: none
	********************************************************************* */
	public void respond (View view){
		/**
		 * View::findViewByID()
		 * View::getText()
		 * Toast::makeText()
		 * BufferedReader::readLine()
		 * BufferedReader::close()
		 * de.greenrobot.event.EventBus::getDefault().postSticky()
		 * Activity::startActivity()
		 */
		String filename = new String();
		filename = ((EditText)findViewById(R.id.editText1)).getText().toString();
		try {
			BufferedReader buf = new BufferedReader(new InputStreamReader(openFileInput(filename), "UTF-8"));
			String[] in = new String[20];
			int count = 0;
			Toast.makeText(this, LOAD, Toast.LENGTH_LONG).show();
			while ((in[count] = buf.readLine()) != null){
			//while (!buf.equals(null)) {
				//in[count] = buf.readLine();
				count++;
			}
			buf.close();
			tournament.newGame();
			if (!tournament.loadGame(in)) {
				Intent intent = new Intent(this, CheckStart.class);
				de.greenrobot.event.EventBus.getDefault().postSticky(tournament);
				startActivity(intent);
			} else {
				Intent intent = new Intent(this, StartActivity.class);
				de.greenrobot.event.EventBus.getDefault().postSticky(tournament);
				startActivity(intent);
			}


		} catch (Exception e) {
			((TextView)findViewById(R.id.Msg)).setText(ERROR);
		}
	}
	
	
}
