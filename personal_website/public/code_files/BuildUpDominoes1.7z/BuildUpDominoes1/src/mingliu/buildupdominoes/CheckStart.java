package mingliu.buildupdominoes;

import de.greenrobot.event.EventBus;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class CheckStart extends Activity {
	protected static final String EXTRA = "mingliue.buildupdominoes.START";
	protected Tournament tournament;

	
	/**********************************************************************
	Function Name: onCreate
	Purpose: sets the TextView for start of game
	@param Parameters: Bundle
	@return Return Value: none
	Assistance Received: none
	********************************************************************* */
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		/**
		 * EventBus::getDefault()::removeStickyEven()
		 */
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_check_start);
		tournament = (Tournament)EventBus.getDefault().removeStickyEvent(Tournament.class);
		update();

	}
	/**********************************************************************
	Function Name: respond
	Purpose: responds to the "continue" button being pressed 
	@param Parameters: Bundle
	@return Return Value: none
	Assistance Received: none
	********************************************************************* */
	public void respond(View view) {
		/**
		 * Tournament::getGmae()
		 * Player::getStart()
		 * Domino::getValue()
		 * Game::shuffleGame()
		 * CheckStart::update()
		 * de.greenrobot.event.EventBus::getDefault().postSticky()
		 * Activity::startActivity()
		 */
		if (view.getId() == R.id.button1) {
			if (tournament.getGame().playerH.getStart().getValue() == tournament
					.getGame().playerC.getStart().getValue()) {
				tournament.getGame().shuffleGame();
				update();
			} else {
				Intent intent = new Intent(this, StartActivity.class);
				tournament.getGame().startTurn();
				tournament.getGame().beginHand();
				intent.putExtra(EXTRA, tournament.getGame().getTurn());
				de.greenrobot.event.EventBus.getDefault().postSticky(tournament);
				startActivity(intent);
			}
		}
	}
	/**********************************************************************
	Function Name: update
	Purpose: sets the buttons to the dominoes
	@param Parameters: Bundle
	@return Return Value: none
	Assistance Received: none
	********************************************************************* */
	private void update() {
		/**
		 * View::findViewById()
		 * View::setText()
		 * Tournament::getGame()
		 * Player::getStart()
		 * Domino::getDomino()
		 * Domino::getValue()
		 */
		((Button) findViewById(R.id.playertile)).setText(tournament
				.getGame().playerH.getStart().getDomino());
		((Button) findViewById(R.id.comptile)).setText(tournament
				.getGame().playerC.getStart().getDomino());
		if (tournament.getGame().playerH.getStart().getValue() == tournament
				.getGame().playerC.getStart().getValue()) {
			((TextView) findViewById(R.id.Msg))
					.setText("The tiles are equal, we must shuffle again!");
		} else if (tournament.getGame().playerH.getStart().getValue() > tournament
				.getGame().playerC.getStart().getValue()) {
			((TextView) findViewById(R.id.Msg))
					.setText("Your tile is greater. \nProceed.");
		} else if (tournament.getGame().playerH.getStart().getValue() < tournament
				.getGame().playerC.getStart().getValue()) {
			((TextView) findViewById(R.id.Msg))
					.setText("The Computer's tile is greater. \nIt goes first.");
		}
	}


}
