package mingliu.buildupdominoes;

import java.util.Arrays;
import java.util.Collections;

public class Tournament {

	protected int playerWins;
	protected int cpuWins;
	protected Game game;

	public Tournament() {
		playerWins = 0;
		cpuWins = 0;
		game = new Game();
	}
	/**********************************************************************
	Function Name: getGame
	Purpose: gets the Game object being used
	@param Parameters: none
	@return Return Value: Game object being used
	Assistance Received: none
	********************************************************************* */
	public Game getGame() {
		return game;
	}
	/**********************************************************************
	Function Name: getGame
	Purpose: gets the integer of the number of rounds the computer has won
	@param Parameters: none
	@return Return Value: integer represeting the number of rounds the computer has won
	Assistance Received: none
	********************************************************************* */
	public int getCompWins() {
		return cpuWins;
	}
	/**********************************************************************
	Function Name: getGame
	Purpose: gets the integer of the number of rounds the player has won
	@param Parameters: none
	@return Return Value: integer represeting the number of rounds the player has won
	Assistance Received: none
	********************************************************************* */
	public int getPlayWins() {
		return playerWins;
	}
	/**********************************************************************
	Function Name: newGame
	Purpose: Creates a new Game object and sets the values 
	@param Parameters: none
	@return Return Value: none
	Assistance Received: none
	********************************************************************* */
	public void newGame() {
		game = new Game();
		game.newGame();
	}
	/**********************************************************************
	Function Name: endHand
	Purpose: checks if the hand has ended and if the number of MAX_HANDS is exceeded and ends the round if it does
	@param Parameters: none
	@return Return Value: Boolean value, true if the round has ended, false if it has not
	Assistance Received: none
	********************************************************************* */
	public boolean endHand() {
		game.checkEndHand();
		if (game.getHands() > Game.MAX_HANDS) {
			/**if the maximum number of hands is exceeded, update the winner*/
			if (game.getHuman().getScore() > game.getComp().getScore()) {
				playerWins++;
			} else if (game.getHuman().getScore() < game.getComp().getScore()) {
				cpuWins++;
			}
			return true;
		} else {
			return false;
		}

	}
	/**********************************************************************
	Function Name: endTour
	Purpose: gets the winner of the Tournament
	@param Parameters: none
	@return Return Value: String with a message of who won
	Assistance Received: none
	********************************************************************* */
	public String endTour() {
		if (cpuWins > playerWins) {
			return "The computer has bested us this day. We must try again later";
		} else if (cpuWins < playerWins) {
			return "We have triumphed in the end";
		} else {
			return "We are evenly matched against the computer";
		}
	}
	/**********************************************************************
	Function Name: saveGame
	Purpose: saves the game to a file
	@param Parameters: none
	@return Return Value: String that needs to be printed to a file
	Assistance Received: none
	********************************************************************* */
	public String saveGame() {
		String retStr = new String();
		retStr += "Computer: \n";
		retStr += "\tStacks: " + game.getBoard().getStringCPUBoard() + "\n";
		retStr += "\tBoneyard: " + game.getComp().getBoneyard().getDeck()
				+ "\n";
		retStr += "\tHand: " + game.getComp().getHandString() + "\n";
		retStr += "\tScore: " + Integer.toString(game.getComp().getScore())
				+ "\n";
		retStr += "\tRounds Won: " + Integer.toString(cpuWins) + "\n";
		retStr += "\n";
		retStr += "Human: \n";
		retStr += "\tStacks: " + game.getBoard().getStringHumanBoard() + "\n";
		retStr += "\tBoneyard: " + game.getHuman().getBoneyard().getDeck()
				+ "\n";
		retStr += "\tHand: " + game.getHuman().getHandString() + "\n";
		retStr += "\tScore: " + Integer.toString(game.getHuman().getScore())
				+ "\n";
		retStr += "\tRounds Won: " + Integer.toString(playerWins) + "\n";
		retStr += "\n";
		retStr += "Turn: ";
		if (game.getTurn() == 0) {
			retStr += "Computer";
		} else {
			retStr += "Human";
		}

		return retStr;
	}
	/**********************************************************************
	Function Name: loadGame
	Purpose: loads the game from a text file
	@param Parameters: an array of strings from the file, each string is a new line
	@return Return Value: Boolean value indicating if the first hand has been dealt
	Local Variables:
				domArr, an array of dominoes that will be passed to setters
				domList, an array of strings parsed from input
				needHands, a boolean that indiates if the first had was dealt
	Algorithm:	1) Each field is trimmed
				2) Each field is split with using "[ ]"
				3) The split strings are saved into domList and parsed into dominoes into domArr
				4) Setters are called for that field
					a) the Array for boneyards had to be reversed because it was reading the leftmost domino as the bottom, not the top
	Assistance Received: none
	********************************************************************* */
	public boolean loadGame(String[] input) {
		/**
		 * trim()
		 * split()
		 * Game::getBoard()
		 * Board::setField()
		 * Collections::reverse()
		 * Arrays::asList()
		 * Game::getComp()
		 * Player::getBoneyard()
		 * Stack::setStack()
		 * Game::setHands()
		 * Player::setHand()
		 * Player::setScore()
		 * Game::getHuman()
		 * Game::setTurn()
		 */
		Domino[] domArr;
		String[] domList;
		boolean needHands = false;

		/** parses computer stacks*/
		input[1] = input[1].trim();
		domList = input[1].split("[ ]");
		/** beings at 1 to skip over trying to parse labels*/
		domArr = new Domino[domList.length - 1];
		for (int count = 1; count < domList.length; count++) {
			domArr[count - 1] = new Domino(domList[count]);
		}
		game.getBoard().setField(domArr, domArr.length, 0);

		/** parses computer boneyard*/
		input[2] = input[2].trim();
		domList = input[2].split("[ ]");
		/** beings at 1 to skip over trying to parse labels*/
		domArr = new Domino[domList.length - 1];
		for (int count = 1; count < domList.length; count++) {
			domArr[count - 1] = new Domino(domList[count]);
		}
		/** stack array is populated backwards*/
		Collections.reverse(Arrays.asList(domArr));
		game.getComp().getBoneyard().setStack(domArr, domArr.length);
		switch (domArr.length) {
		case 22:
			game.setHands(0);
			/** checks if hand has not been dealt*/
			needHands = true;
			break;
		case 16:
			game.setHands(1);
			break;
		case 10:
			game.setHands(2);
			break;
		case 4:
			game.setHands(3);
			break;
		case 0:
			game.setHands(4);
			break;
		default:
			game.setHands(0);
		}

		/** parses computer hand*/
		input[3] = input[3].trim();
		domList = input[3].split("[ ]");
		/** beings at 1 to skip over trying to parse labels*/
		domArr = new Domino[domList.length - 1];
		for (int count = 1; count < domList.length; count++) {
			domArr[count - 1] = new Domino(domList[count]);
		}
		game.getComp().setHand(domArr);

		/** parses computer score*/
		input[4] = input[4].trim();
		domList = input[4].split("[ ]");
		game.getComp().setScore(Integer.parseInt(domList[1]));

		/** parses computer rounds won*/
		input[5] = input[5].trim();
		domList = input[5].split("[ ]");
		/** "Rounds Won: x" will parse into [Rounds, Won:, x]*/
		cpuWins = (Integer.parseInt(domList[2]));

		/** ------------------------------------------------------Parse Player
		Info------------------------

		parses player stacks*/
		input[8] = input[8].trim();
		domList = input[8].split("[ ]");
		/** beings at 1 to skip over trying to parse labels*/
		domArr = new Domino[domList.length - 1];
		for (int count = 1; count < domList.length; count++) {
			domArr[count - 1] = new Domino(domList[count]);
		}
		game.getBoard()
				.setField(domArr, domArr.length, Board.PLAYER_TILE_START);

		/** parses player boneyard*/
		input[9] = input[9].trim();
		domList = input[9].split("[ ]");
		/** beings at 1 to skip over trying to parse labels*/
		domArr = new Domino[domList.length - 1];
		for (int count = 1; count < domList.length; count++) {
			domArr[count - 1] = new Domino(domList[count]);
		}
		/** stack array is populated backwards*/
		Collections.reverse(Arrays.asList(domArr));
		game.getHuman().getBoneyard().setStack(domArr, domArr.length);

		/** parses player hand*/
		input[10] = input[10].trim();
		domList = input[10].split("[ ]");

		/** beings at 1 to skip over trying to parse labels*/
		domArr = new Domino[domList.length - 1];
		for (int count = 1; count < domList.length; count++) {
			domArr[count - 1] = new Domino(domList[count]);
		}
		game.getHuman().setHand(domArr);

		/** parses player score*/
		input[11] = input[11].trim();
		domList = input[11].split("[ ]");
		game.getHuman().setScore(Integer.parseInt(domList[1]));

		/** parses player rounds won*/
		input[12] = input[12].trim();
		domList = input[12].split("[ ]");
		/** "Rounds Won: x" will parse into [Rounds, Won:, x]*/
		playerWins = (Integer.parseInt(domList[2]));

		/**if hands have been dealt, then parse the current player */
		if (needHands == false) {
			input[14] = input[14].trim();
			domList = input[14].split("[ ]");
			if (domList[1].equals("Computer")) {
				game.setTurn(0);
			} else {
				game.setTurn(1);
			}
		}
		if (needHands == true) {
			return false;
		}
		return true;

	}

}
