package mingliu.buildupdominoes;

import de.greenrobot.event.EventBus;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

public class Again extends Activity {
	protected Tournament tournament;
	
	
	/**********************************************************************
	Function Name: onCreate
	Purpose: sets the TextView for end of round
	@param Parameters: Bundle
	@return Return Value: none
	Assistance Received: none
	********************************************************************* */
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		/**
		 * EventBus::getDefault()::removeStickyEven()
		 * View::findViewById()
		 * View::setText()
		 */
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_again);
		tournament = (Tournament) EventBus.getDefault().removeStickyEvent(Tournament.class);
		((TextView) findViewById(R.id.compRounds)).setText(Integer.toString(tournament
				.getCompWins()));
		((TextView) findViewById(R.id.playerRounds)).setText(Integer.toString(tournament
				.getPlayWins()));
		((TextView) findViewById(R.id.compScore)).setText(Integer.toString(tournament.getGame()
				.getComp().getScore()));
		((TextView) findViewById(R.id.playerScore)).setText(Integer.toString(tournament.getGame()
				.getHuman().getScore()));
		((TextView) findViewById(R.id.textView1)).setText(tournament.getGame().getWinner());
	}
	
	/**********************************************************************
	Function Name: restart
	Purpose: responds to Again! button by starting a new game
	@param Parameters: View object being responded to 
	@return Return Value: none
	Assistance Received: none
	********************************************************************* */
	public void restart(View view) {
		/** 
		 * Tournament::newGame()
		 * de.greenrobot.event.EventBus::getDefault().postSticky()
		 * Activity::startActiviy()
		 */
		tournament.newGame();
		Intent intent = new Intent(this, CheckStart.class);
		de.greenrobot.event.EventBus.getDefault().postSticky(tournament);
		startActivity(intent);
	}
	/**********************************************************************
	Function Name: leave
	Purpose: responds to the "Exit" button by toasting and moving the app to the back
	@param Parameters: View object being responded to 
	@return Return Value: none
	Assistance Received: none
	********************************************************************* */
	public void leave(View view) {
		/**
		 * Tournament::endTour()
		 * View::setText()
		 * moveTaskToBack()
		 */
		Toast.makeText(this, tournament.endTour(), Toast.LENGTH_LONG).show();
		((TextView) findViewById(R.id.textView1)).setText(tournament.endTour());
		moveTaskToBack(true);
	}
	
	
}
