package mingliu.buildupdominoes;

public class Computer extends Player{
	public Computer () {
		boneyard = new Stack(COMPUTER);
		boneyard.shuffleDeck();
	}
	/**********************************************************************
	Function Name: beginStack
	Purpose: draws 6 dominoes from the computer's stack to put onto the field
	@param Parameters: A Board object that represents the field
	@return Return Value: none
	Assistance Received: none
	********************************************************************* */
	public void beginStack(Board field) {
		/** Board::getStacks()
		 * Stack::draw()
		 * */
		/**draws 6 tiles from each boneyard to use as the board*/
		for (int count = 0; count < Board.PLAYER_TILE_START; count++) {
			field.getStacks()[count]= new Domino(boneyard.draw());
		}
		
	}
	/**********************************************************************
	Function Name: thinkCPU
	Purpose: computer playing algorithm, computer will see which move is best and print why, 
	@param Parameters: A Board object that represents the field that the code will look for plays on
	@return Return Value: a string that holds the "stack name:IndexOfTileInHand" the code thinks should be played
	Local Variables: handTile, integer that holds the index of the tile in hand 
					fieldLocation, integer that holds the index of the stack on the board
					field2, integer that holds the index of another stack on the board, helps find nonopposed enemy tiles
					legal, a boolean that holds if the move is legal
					output, a string that outs the output
					reason, an integer that holds the string to be output
					location, a string that holds the name of the stack to hold it
	Algorithm:	1) find the first opposing stack
				2) find the lowest opposing stack
				3) if there are not opposing stacks, pick the lowest stack
				4) find the first tile that can be played that is not a double
				5) if no non doubles can be played, check for the first double
					a) if no doubles exists, set reason to 0
					b) find the first nondouble opposing tile
						i) find the largest non double opposing tile
						ii) find the lowest double in hand
					c) if the location is also a double
						i) find lowest double that is greater than the location's value
				6) finds the lowest that can be played
				7) checks if the move is legal
				8) if pass is chosen, or move is illegal, go through and find if any combination works to validate
				9) converts fieldLocation to a string stored in location
				10) sets output string accordingly
	Assistance Received: none
	********************************************************************* */
	public String thinkCPU(Board field) {
		/**
			Domino::getColor()
			Domino::getValue()
			Domino::getDouble()
			Board::getStacks()
			Player::tryPlace()
			Board::indexToStack
		*/
		/**holds index of tile from hand*/
		int handTile = -1;
		/**holds the location of a tile on the board*/
		int fieldLocation = -1;
		/**helps find highest non double opposed tile*/
		int field2 = -1;
		/**checks for illegal move*/
		boolean legal;
		/**output string tells what cpu chose; is returned*/
		String output = new String("pass");
		/**reason; 0 is no moves, 1 is lowest possible tile that can be played, 2 is found double to reset stack*/
		int reason = 0;
		/**string that holds the name of the stack to be returned*/
		String location = new String();
		/**finds the first opposing block*/
		for (int count = 0; count < Board.MAX_STACKS; count++) {
			if (field.getStacks()[count].getColor() == HUMAN) {
				fieldLocation = count;
				break;
			}
		}
		/**If no opposing blocks exist*/
		if (fieldLocation == -1) {
			fieldLocation = 0;
			/**finds the lowest valued block*/
			for (int count = 0; count < Board.MAX_STACKS; count++) {
				if (field.getStacks()[count].getValue() < field.getStacks()[fieldLocation].getValue()) {
					fieldLocation = count;
				}
			}
		}
		else {
			/**finds the lowest valued opposing block*/
			for (int count = 0; count < Board.MAX_STACKS; count++) {
				if (field.getStacks()[count].getColor() == HUMAN) {
					if (field.getStacks()[count].getValue() < field.getStacks()[fieldLocation].getValue()) {
						fieldLocation = count;
					}
				}
			}
		}

		/**-------------------------------tile on board located, find a tile in hand--------------
		finds the first tile that is not a double that can be played*/
		for (int count = 0; count < handsize; count++) {
			if (hand[count].getDouble()) {
				continue;
			}
			else if (hand[count].getValue() >= field.getStacks()[fieldLocation].getValue()){
				handTile = count;
			}
		}
		/**if no nondouble tiles can be played*/
		if (handTile == -1) {
			/**finds the first double tile in hand*/
			for (int count = 0; count < handsize; count++) {
				if (hand[count].getDouble()) {
					handTile = count;
					break;
				}
			}
			/**if no double tiles, no tiles can be played */
			if (handTile == -1) {
				reason = 0;
			}
			else {
				/**finds the first non double opposing on the board*/
				for (int count = 0; count < Board.MAX_STACKS; count++) {
					if ((!field.getStacks()[count].getDouble()) && field.getStacks()[count].getColor() == HUMAN) {
						field2 = count;
						break;
					}
				}
				/**if nondouble opposing tiles*/
				if (field2 != -1) {
					fieldLocation = field2;
					/**find the largest non double opposing on the board*/
					for (int count = 0; count < Board.MAX_STACKS; count++) {
						if ((!field.getStacks()[count].getDouble()) && field.getStacks()[count].getColor() == HUMAN && field.getStacks()[count].getValue() > field.getStacks()[field2].getValue()) {
							fieldLocation = count;
						}
					}
					/**finds the lowest double in hand*/
					for (int count = 0; count < handsize; count++) {
						if (hand[count].getDouble() && hand[count].getValue() < hand[handTile].getValue()) {
							handTile = count;

						}
					}
					/**sets reason to be interepted later*/
					reason = 2;
				}
				
				/**if target location is also a double tile*/
				else {
					/**finds the first double tile in hand greater than selected tile*/
					handTile = -1;
					for (int count = 0; count < handsize; count++) {
						if (hand[count].getDouble() && hand[count].getValue() > field.getStacks()[fieldLocation].getValue()) {
							handTile = count;
							break;

						}
					} if (handTile != -1) {
						/**finds the lowest double tile in hand greater than selected tile*/
						for (int count = 0; count < handsize; count++) {
							if (hand[count].getDouble() && hand[count].getValue() < hand[handTile].getValue() && hand[count].getValue() > field.getStacks()[fieldLocation].getValue()) {
								handTile = count;
							}
						}
						/**sets reason to be interepted later*/
						reason = 1;
					}
				}
			}
		}
		/**if nondouble tiles can be played on the lowest tile*/
		else {
			/**find lowest nondouble tile that can be played*/
			for (int count = 0; count < handsize; count++) {
				if (!hand[count].getDouble() && hand[count].getValue() < hand[handTile].getValue() && hand[count].getValue() >= field.getStacks()[fieldLocation].getValue()) {
					handTile = count;
				}
			}
			/**sets reason to be interepted later*/
			reason = 1;
		}
		/**try the move, if it doesn't work, just pass
		just in case*/
		if (reason == 1 || reason == 2) {
			/**attempts to play*/
			legal = tryPlaceDomino(handTile, fieldLocation, field);
			/**if illegal, set reason to pass*/
			if (legal == false) {
				reason = 0;				
			}
		} else if (reason == 0) {
			/**If pass is suggested, one more pass to brute force it to see if solutions are left*/
			for (int count = 0; count < handsize; count++) {
				for (int count2 = 0; count2 < Board.MAX_STACKS; count2++){
					if (tryPlaceDomino(count, count2, field)) {
						fieldLocation = count2;
						handTile = count;
						reason = 1;
						break;
					}
				}
			}
		}

		/**if the index on the board is less than 6, recognize that it is on the computer's side of the board
		if the index on the board is greater than 6, recognize that it is on the humans's side of the board
		then convert the index to a string of either "W[1-6]" or "B[1-6]" 
		The +1 is because the index of the array starts at 0, but the stack names start from W1*/
		location = field.indexToStack(fieldLocation);
		/**inteprets the reason for the computer's play*/
		switch (reason) {
		case 0: 
			output = PASS;
			break;
		case 1:
			output = location + ":" + Integer.toString(handTile) + " because it is the lowest tile to play.";
			break;
		case 2:
			output = location + ":" + Integer.toString(handTile)+ " because it would reset the stack.";
			break;
		}

		
		return output;
	}

	/**********************************************************************
	Function Name: playCPU
	Purpose: the computer will try to play a tile
	@param Parameters: A Board object that represents the field
	@return Return Value: A String containing where the computer placed a tile and why
	Assistance Received: none
	********************************************************************* */
	public String playCPU(Board field) {
		/**
			Player::thinkCPU()
			Player::pass()
			Player::parseStackName()
			Player::placeDomino()
			Domino::getString
		*/

		/**gets the command from the thinkCPU algorithm to be parsed*/
		String command = thinkCPU(field);
		int stackNumber;
		int tileIndexInHand;

		/**passes if ai recommends pass*/
		if (command.equals(PASS)) {
			setPass(true);
			return PASS;
		}
		/**parses part of the command string into a location*/
		stackNumber = parseStackName(command);

		/**4th char of input is tile in hand*/
		tileIndexInHand = command.charAt(3)-48;
		/**plays the domino*/
		placeDomino(tileIndexInHand, stackNumber, field);
		
		return "Computer plays " + field.getStacks()[stackNumber].getString()+ " at "+ command.substring(0,2) + command.substring(4);

	}
	
	
}
