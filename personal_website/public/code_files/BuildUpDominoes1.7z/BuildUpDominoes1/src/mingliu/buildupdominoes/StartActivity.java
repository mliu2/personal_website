package mingliu.buildupdominoes;

import de.greenrobot.event.EventBus;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class StartActivity extends Activity {
	protected static final String HELP = "Help";
	protected static final String CONTINUE = "Continue";
	protected static final String PASS = "Pass";
	
	protected int indexHand;
	protected int indexStacks;
	protected String msg;
	protected int turn;
	protected Tournament tournament;
	
	/**********************************************************************
	Function Name: onCreate
	Purpose: sets the view for the playing UI
	@param Parameters: Bundle
	@return Return Value: none
	Assistance Received: none
	********************************************************************* */
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		/**
		 * EventBus::getDefault()::removeStickyEven()
		 * Tournament::getGame()
		 * Game::getTurn()
		 * StartActivity::updateTurn()
		 * StartActivity::updateScores()
		 * StartActivity::update()
		 * StartActivity::CompPlay()
		 */
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_start);
		tournament = (Tournament) EventBus.getDefault().removeStickyEvent(
				Tournament.class);
		msg = new String();
		turn = tournament.getGame().getTurn();
		updateTurn();
		updateScores(tournament);
		update();
		indexHand = -1;
		if (turn == 0) {
			CompPlay();
		}

	}
	

	/**********************************************************************
	Function Name: respond
	Purpose: responds to tiles on the board being clicked
	@param Parameters: View being responded to 
	@return Return Value: none
	Assistance Received: none
	********************************************************************* */
	public void respond(View view) {
		/**
		 * Tournament::getGame()
		 * Game::humanPlay()
		 * StartActivity::updateMsg()
		 * Game::setTurn()
		 * StartActivity::update()
		 * StartActivity::updateTurn()
		 * StartActivity::updateContextualButton()
		 */
		if (turn == 1) {
			/**Only perform action if hand has a tile selected */
			if (indexHand != -1) {
				switch (view.getId()) {
				case R.id.tile1:
					indexStacks = 0;
					break;
				case R.id.tile2:
					indexStacks = 1;
					break;
				case R.id.tile3:
					indexStacks = 2;
					break;
				case R.id.tile4:
					indexStacks = 3;
					break;
				case R.id.tile5:
					indexStacks = 4;
					break;
				case R.id.tile6:
					indexStacks = 5;
					break;
				case R.id.tile7:
					indexStacks = 6;
					break;
				case R.id.tile8:
					indexStacks = 7;
					break;
				case R.id.tile9:
					indexStacks = 8;
					break;
				case R.id.tile10:
					indexStacks = 9;
					break;
				case R.id.tile11:
					indexStacks = 10;
					break;
				case R.id.tile12:
					indexStacks = 11;
					break;
				}
				/**Attempts to play and updates message */
				msg = tournament.getGame().humanPlay(indexHand, indexStacks);
				updateMsg(msg);
			} else {
				updateMsg("No tile selected");
				msg = Game.ILLEGAL;
			}
			/**reset hand tile selection*/
			indexHand = -1;
			/**if play was allowed, update and set contextual button to continue */
			if (!msg.equals(Game.ILLEGAL)) {
				turn = 0;
				tournament.getGame().setTurn(turn);
				updateTurn();
				update();
				updateContextualButton(CONTINUE);
			} else {
				turn = 1;
			}

		}

	}
	/**********************************************************************
	Function Name: respondSave
	Purpose: responds to "Save" button and start SaveActivity
	@param Parameters: View being responded to 
	@return Return Value: none
	Assistance Received: none
	********************************************************************* */
	public void respondSave(View view) {
		/**
		 * de.greenrobot.event.EventBus::getDefault().postSticky()
		 * Activity::startActivity()
		 */
		Intent intent = new Intent(this, SaveActivity.class);
		de.greenrobot.event.EventBus.getDefault().postSticky(tournament);
		startActivity(intent);
	}
	/**********************************************************************
	Function Name: respondContext
	Purpose: responds to Contextual button based on the text of the button
	@param Parameters: View being responded to 
	@return Return Value: none
	Assistance Received: none
	********************************************************************* */
	public void respondContext(View view) {
		/**
		 * View::getId()
		 * View::findViewById()
		 * View::getText()
		 * StartActivity::CompPlay()
		 * StartActivity::updateMsg()
		 * Tournament::getGame()
		 * Game::help()
		 */
		if (view.getId() == R.id.help) {
			if (((Button) findViewById(R.id.help)).getText().toString()
					.equals(CONTINUE)) {
				CompPlay();
			} else if (((Button) findViewById(R.id.help)).getText().toString()
					.equals(PASS)) {
				CompPlay();
			} else if (((Button) findViewById(R.id.help)).getText().toString()
					.equals(HELP)) {
				updateMsg(tournament.getGame().help());

			}
		}
	}
	/**********************************************************************
	Function Name: respondHand
	Purpose: responds to tiles in the hand
	@param Parameters: View being responded to 
	@return Return Value: none
	Assistance Received: none
	********************************************************************* */
	public void respondHand(View view) {
		/**
		 * Tournament::getGame()
		 * Game::canHumanPass()
		 * StartActivity::updateMsg()
		 * Game::getHuman()
		 * Player::getHandSize()
		 * Domino::getString()
		 */
		indexHand = -1;
		if (turn == 1) {
			if (tournament.getGame().canHumanPass()) {
				updateMsg("We must pass.");
			} else {
				switch (view.getId()) {
				case R.id.hand1:
					if (tournament.getGame().getHuman().getHandSize() >= 1) {
						indexHand = 0;
					}
					break;
				case R.id.hand2:
					if (tournament.getGame().getHuman().getHandSize() >= 2) {
						indexHand = 1;
					}
					break;
				case R.id.hand3:
					if (tournament.getGame().getHuman().getHandSize() >= 3) {
						indexHand = 2;
					}
					break;
				case R.id.hand4:
					if (tournament.getGame().getHuman().getHandSize() >= 4) {
						indexHand = 3;
					}
					break;
				case R.id.hand5:
					if (tournament.getGame().getHuman().getHandSize() >= 5) {
						indexHand = 4;
					}
					;
					break;
				case R.id.hand6:
					if (tournament.getGame().getHuman().getHandSize() >= 6) {
						indexHand = 5;
					}
					break;
				}
				if (indexHand != -1) {
					updateMsg("We have selected "
							+ tournament.getGame().getHuman().getHand()[indexHand]
									.getString());
				}
			}
		}
	}
	/**********************************************************************
	Function Name: CompPlay
	Purpose: Allows the computer to play
	@param Parameters: none
	@return Return Value: none
	Assistance Received: none
	********************************************************************* */
	private void CompPlay() {
		/**
		 * StartActivity::updateHand()
		 * Tournament::getGame()
		 * Game::compPlay()
		 * StartActivity::updateMsg()
		 * StartActivity::update()
		 * Game::setTurn()
		 * StartActivity::updateTurn()
		 * StartActivity::updateContextualButton()
		 * StartActivity::checkEnd()
		 * Game::canHumanPass()
		 */
		updateHand();
		updateMsg(tournament.getGame().compPlay());
		update();
		turn = 1;
		tournament.getGame().setTurn(turn);
		updateTurn();
		updateContextualButton(HELP);
		checkEnd();
		if (tournament.getGame().canHumanPass()) {
			updateContextualButton(PASS);
		}
		updateHand();
	}
	/**********************************************************************
	Function Name: checkEnd
	Purpose: checks if the hand has ended and if the game has ended
	@param Parameters: none
	@return Return Value: none
	Assistance Received: none
	********************************************************************* */
	private void checkEnd() {
		/**
		 * de.greenrobot.event.EventBus::getDefault().postSticky()
		 * Activity::startActivity()
		 * StartActivity::updateScores()
		 * StartActivity::update()
		 */
		if (tournament.endHand()) {
			Intent intent = new Intent(this, Again.class);
			de.greenrobot.event.EventBus.getDefault().postSticky(tournament);
			startActivity(intent);
		}
		updateScores(tournament);
		update();
	}
	/**********************************************************************
	Function Name: update
	Purpose: updates all the tiles in the hand and board
	@param Parameters: none
	@return Return Value: none
	Assistance Received: none
	********************************************************************* */
	private void update() {
		/**
		 * View::findViewById()
		 * View::setText()
		 * Tournament::getGame()
		 * Game::getBoard()
		 * Board::getStacks()
		 * Domino::getDomino()
		 * StartActivity::updateColor()
		 */
		((Button) findViewById(R.id.tile1)).setText(tournament.getGame()
				.getBoard().getStacks()[0].getDomino());
		updateColor(tournament.getGame().getBoard().getStacks()[0], R.id.tile1);
		((Button) findViewById(R.id.tile2)).setText(tournament.getGame()
				.getBoard().getStacks()[1].getDomino());
		updateColor(tournament.getGame().getBoard().getStacks()[1], R.id.tile2);
		((Button) findViewById(R.id.tile3)).setText(tournament.getGame()
				.getBoard().getStacks()[2].getDomino());
		updateColor(tournament.getGame().getBoard().getStacks()[2], R.id.tile3);
		((Button) findViewById(R.id.tile4)).setText(tournament.getGame()
				.getBoard().getStacks()[3].getDomino());
		updateColor(tournament.getGame().getBoard().getStacks()[3], R.id.tile4);
		((Button) findViewById(R.id.tile5)).setText(tournament.getGame()
				.getBoard().getStacks()[4].getDomino());
		updateColor(tournament.getGame().getBoard().getStacks()[4], R.id.tile5);
		((Button) findViewById(R.id.tile6)).setText(tournament.getGame()
				.getBoard().getStacks()[5].getDomino());
		updateColor(tournament.getGame().getBoard().getStacks()[5], R.id.tile6);
		((Button) findViewById(R.id.tile7)).setText(tournament.getGame()
				.getBoard().getStacks()[6].getDomino());
		updateColor(tournament.getGame().getBoard().getStacks()[6], R.id.tile7);
		((Button) findViewById(R.id.tile8)).setText(tournament.getGame()
				.getBoard().getStacks()[7].getDomino());
		updateColor(tournament.getGame().getBoard().getStacks()[7], R.id.tile8);
		((Button) findViewById(R.id.tile9)).setText(tournament.getGame()
				.getBoard().getStacks()[8].getDomino());
		updateColor(tournament.getGame().getBoard().getStacks()[8], R.id.tile9);
		((Button) findViewById(R.id.tile10)).setText(tournament.getGame()
				.getBoard().getStacks()[9].getDomino());
		updateColor(tournament.getGame().getBoard().getStacks()[9], R.id.tile10);
		((Button) findViewById(R.id.tile11)).setText(tournament.getGame()
				.getBoard().getStacks()[10].getDomino());
		updateColor(tournament.getGame().getBoard().getStacks()[10],
				R.id.tile11);
		((Button) findViewById(R.id.tile12)).setText(tournament.getGame()
				.getBoard().getStacks()[11].getDomino());
		updateColor(tournament.getGame().getBoard().getStacks()[11],
				R.id.tile12);
		((Button) findViewById(R.id.hand1)).setText(tournament.getGame()
				.getHuman().getHand()[0].getDomino());
		updateColor(tournament.getGame().getHuman().getHand()[0], R.id.hand1);
		((Button) findViewById(R.id.hand2)).setText(tournament.getGame()
				.getHuman().getHand()[1].getDomino());
		updateColor(tournament.getGame().getHuman().getHand()[1], R.id.hand2);
		((Button) findViewById(R.id.hand3)).setText(tournament.getGame()
				.getHuman().getHand()[2].getDomino());
		updateColor(tournament.getGame().getHuman().getHand()[2], R.id.hand3);
		((Button) findViewById(R.id.hand4)).setText(tournament.getGame()
				.getHuman().getHand()[3].getDomino());
		updateColor(tournament.getGame().getHuman().getHand()[3], R.id.hand4);
		((Button) findViewById(R.id.hand5)).setText(tournament.getGame()
				.getHuman().getHand()[4].getDomino());
		updateColor(tournament.getGame().getHuman().getHand()[4], R.id.hand5);
		((Button) findViewById(R.id.hand6)).setText(tournament.getGame()
				.getHuman().getHand()[5].getDomino());
		updateColor(tournament.getGame().getHuman().getHand()[5], R.id.hand6);
	}
	/**********************************************************************
	Function Name: updateColor
	Purpose: updates a button based on the corresponding domino
	@param Parameters: Domino object, not being modified, that is being updated from;
	 					integer of the id of the View being responded to 
	@return Return Value: none
	Assistance Received: none
	********************************************************************* */
	private void updateColor(Domino input, int viewID) {
		/**
		 * Domino::getColor()
		 * View::findViewById()
		 * View::setTextColor()
		 * View::setBackgroundColor()
		 */
		if (input.getColor() == 'W') {
			((Button) findViewById(viewID)).setTextColor(Color.BLACK);
			((Button) findViewById(viewID)).setBackgroundColor(Color.LTGRAY);
		}
		if (input.getColor() == 'B') {
			((Button) findViewById(viewID)).setTextColor(Color.WHITE);
			((Button) findViewById(viewID)).setBackgroundColor(Color
					.parseColor("#2C2C2C"));
		}
		if (input.getColor() == 'E') {
			((Button) findViewById(viewID)).setBackgroundColor(Color.WHITE);
			((Button) findViewById(viewID)).setText("");
		}
	}
	/**********************************************************************
	Function Name: updateMsg
	Purpose: updates a message TextView using a String
	@param Parameters: String with the message to be displayed
	@return Return Value: none
	Assistance Received: none
	********************************************************************* */
	public void updateMsg(String string) {
		/**
		 * View::findViewById()
		 * View::setText()
		 */
		((TextView) findViewById(R.id.HelpText)).setText(string);
	}
	/**********************************************************************
	Function Name: updateContextualButton
	Purpose: updates a button based on a string
	@param Parameters: String to be updated from
	@return Return Value: none
	Assistance Received: none
	********************************************************************* */
	private void updateContextualButton(String string) {
		/**
		 * View::findViewById()
		 * View::setText()
		 */
		((Button) findViewById(R.id.help)).setText(string);
	}
	/**********************************************************************
	Function Name: updateScores
	Purpose: updates the score display fron a tournament
	@param Parameters: String to be updated from
	@return Return Value: none
	Assistance Received: none
	********************************************************************* */
	private void updateScores(Tournament tournament) {
		/**
		 * Tournament::getCompWins()
		 * Tournament::getPlayWIns()
		 * Tournament::getGame()
		 * Game::getComp()
		 * Game::getHuman()
		 * Player::getScore()
		 */
		((TextView) findViewById(R.id.CompRounds)).setText(Integer
				.toString(tournament.getCompWins()));
		((TextView) findViewById(R.id.PlayerRound)).setText(Integer
				.toString(tournament.getPlayWins()));
		((TextView) findViewById(R.id.CompScore)).setText(Integer
				.toString(tournament.getGame().getComp().getScore()));
		((TextView) findViewById(R.id.PlayScore)).setText(Integer
				.toString(tournament.getGame().getHuman().getScore()));
	}
	/**********************************************************************
	Function Name: updateTurn
	Purpose: updates the turn display
	@param Parameters: none
	@return Return Value: none
	Assistance Received: none
	********************************************************************* */
	private void updateTurn() {
		/**
		 * View::findViewById()
		 * View::setText()
		 * StartActivity::setText()
		 */
		if (turn == 0) {
			((TextView) findViewById(R.id.turn)).setText("Computer");
			updateContextualButton(CONTINUE);
		} else if (turn == 1) {
			((TextView) findViewById(R.id.turn)).setText("You");
			updateContextualButton(HELP);
		}
	}
	/**********************************************************************
	Function Name: updatehand
	Purpose: updates the current hand# display
	@param Parameters: none
	@return Return Value: none
	Assistance Received: none
	********************************************************************* */
	private void updateHand() {
		/**
		 * View::findViewById()
		 * View::setText()
		 * StartActivity::setText()
		 * Tournament::getGame()
		 * Game::getHands()
		 */
		((TextView) findViewById(R.id.hand)).setText(Integer.toString(tournament.getGame().getHands()));
	}

	
}
