/************************************************************
 * Name:  Mingzhao Liu                                      *
 * Project:  3, Android/Java Build-up dominoes              *
 * Class:  OPL 366                                          *
 * Date:  11/14/14                                          *
 ************************************************************/

package mingliu.buildupdominoes;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends Activity {
	protected Tournament test;
	
	/**********************************************************************
	Function Name: onCreate
	Purpose: create a new Tournament object
	@param Parameters: Bundle
	@return Return Value: none
	Assistance Received: none
	********************************************************************* */
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		test = new Tournament();
	}
	/**********************************************************************
	Function Name: respond
	Purpose: responds to "New Game" or "Load Game" buttons
	@param Parameters: View object being responded to
	@return Return Value: none
	Assistance Received: none
	********************************************************************* */
	public void respond(View view) {
		/**
		 * View::getId()
		 * MainActivity::newGame()
		 * MainActivity::loadGame()
		 */
		switch (view.getId()) {
		case R.id.button1:
			newGame();
			break;
		case R.id.button2:
			loadGame();
			break;
		}

	}
	/**********************************************************************
	Function Name: loadGame()
	Purpose: starts the LoadActivity activity
	@param Parameters: none
	@return Return Value: none
	Assistance Received: none
	********************************************************************* */
	private void loadGame() {
		/**
		 * de.greenrobot.event.EventBus::getDefault().postSticky()
		 * Activity::startActivity()
		 */
		Intent intent = new Intent(this, LoadActivity.class);
		de.greenrobot.event.EventBus.getDefault().postSticky(test);
		startActivity(intent);
	}
	/**********************************************************************
	Function Name: newGame()
	Purpose: starts the CheckStart activity
	@param Parameters: none
	@return Return Value: none
	Assistance Received: none
	********************************************************************* */
	private void newGame() {
		/**
		 * Tournament::newGame()
		 * de.greenrobot.event.EventBus::getDefault().postSticky()
		 * Activity::startActivity()
		 */
		test.newGame();
		Intent intent = new Intent(this, CheckStart.class);
		de.greenrobot.event.EventBus.getDefault().postSticky(test);
		startActivity(intent);
	}
	

	
}
