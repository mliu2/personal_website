package mingliu.buildupdominoes;

import java.util.Random;

import mingliu.buildupdominoes.Domino;

public class Stack {
	protected static final int MAX_SIZE = 28;
	private int size;
	private Domino[] boneyard;
	
	public Stack(char color) {
		boneyard = new Domino[MAX_SIZE];
		/** count will keep track of the place in the deck array */
		int count = 0;
		/**
		 * countpip1 is a counter variable to track iterations of loop it will
		 * also keep populate the dominoes, pip1 starting from 0 For each value
		 * of pip1, pip2 ranges from 0-6
		 */
		for (int countpip1 = 0; countpip1 <= Domino.MAX_PIP; countpip1++) {
			for (int countpip2 = countpip1; countpip2 <= Domino.MAX_PIP; countpip2++) {
				/** constructs dominoes as color and adds domino to deck */
				boneyard[count] = new Domino(color, countpip1, countpip2);
				/** increments count */
				count++;
			}
		}
		size = count;
	}
	/**********************************************************************
	Function Name: shuffleDeck
	Purpose: shuffles the stack of dominoes
	@param Parameters: none
	@return Return Value: none
	Assistance Received: none
	********************************************************************* */
	public void shuffleDeck() {
		/**
		 * Random::nextInt()
		 */
		Random rnd = new Random();
		for (int count = size - 1; count > 0; count--) {
			int index = rnd.nextInt(count + 1);
			Domino temp = boneyard[index];
			boneyard[index] = boneyard[count];
			boneyard[count] = temp;
		}
	}

	/**Getters	 */
	/**********************************************************************
	Function Name: getDeck
	Purpose: gets the Stack of Dominoes as a string, separated by spaces
	Parameters: none
	Return Value: string of Dominoes, separated by spaces
	Assistance Received: none
	********************************************************************* */
	public String getDeck() {
		/**
		 * Domino::getString()
		 */
		String output = new String();
		for (int count = size - 1; count >= 0; count--) {
			output += boneyard[count].getString() + " ";
		}
		return output;

	}
	/**********************************************************************
	Function Name: getBoneyard
	Purpose: gets the Array of dominoes that represents the Stack object
	@param Parameters: none
	@return Return Value: An array of dominoes that represents the Stack object
	Assistance Received: none
	********************************************************************* */
	public Domino[] getBoneyard() {
		return boneyard;
	}
	/**********************************************************************
	Function Name: get
	Purpose: gets a Domino at a location
	@param Parameters: integer input, the index of the Domino to be retreived
	@return Return Value: Domino at input location
	Assistance Received: none
	********************************************************************* */
	public Domino get(int index) {
		if (index < size) {
			return boneyard[index];
		} else {
			return null;
		}
	}
	/**********************************************************************
	Function Name: getSize
	Purpose: gets the size of the Stack
	@param Parameters: none
	@return Return Value: size of the Stack object
	Assistance Received: none
	********************************************************************* */
	public int getSize() {
		return size;
	}
	/**********************************************************************
	Function Name: draw
	Purpose: "Draw" the top domino from the stack, removing it from the stack and decreasing the stack size
	@param Parameters: none
	@return Return Value: The domino that was drawn
	Assistance Received: none
	********************************************************************* */
	public Domino draw() {
		if (size > 0) {
			return boneyard[--size];
		}
		return null;
	}
	/**********************************************************************
	Function Name: setStack
	Purpose: copies the values of the dominoes in an array
	@param Parameters: Domino Array input, pass by pointer, not modified
				size, the size of the input array
	@return Return Value: none
	Assistance Received: none
	********************************************************************* */
	public void setStack(Domino[] input, int size) {
		/**
		 * Domino::copy()
		 */
		/** copies up to size or Max deck size number of dominoes into the stack */
		for (int count = 0; count < size; count++) {
			if (count >= MAX_SIZE) {
				break;
			}
			boneyard[count].copy(input[count]);
		}
		/**
		 * sets the new size of the deck equal to the size of the array or if
		 * the array exceeds max deck size, the max deck size
		 */
		if (size <= MAX_SIZE) {
			this.size = size;
		} else {
			this.size = MAX_SIZE;
		}
	}

	
}
