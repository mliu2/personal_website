package mingliu.buildupdominoes;

public abstract class Player {
	protected static final char COMPUTER = 'W';
	protected static final char HUMAN = 'B';
	protected static final String PASS = "Computer passes";
	protected static final int MAX_HAND_SIZE = 6;
	
	protected int score;
	protected int handsize;
	protected Stack boneyard;
	protected Domino[] hand;
	protected boolean didPass;
	
	
	
	public Player() {
		didPass = false;
		score = 0;
		handsize = 0;
		hand = new Domino[MAX_HAND_SIZE];
		for (int count = 0; count < MAX_HAND_SIZE; count++) {
			hand[count] = new Domino();
		}
	}
	/**********************************************************************
	Function Name: getScore
	Purpose: gets the player's current score
	@param Parameters: none
	@return Return Value: integer value of the player's score
	Assistance Received: none
	********************************************************************* */
	public int getScore() {
		return score;
	}
	/**********************************************************************
	Function Name: getBoneyard
	Purpose: gets the player's boneyard as a Stack object
	@param Parameters: none
	@return Return Value: a Stack that holds the boneyard
	Assistance Received: none
	********************************************************************* */
	public Stack getBoneyard() {
		return boneyard;
	}
	/**********************************************************************
	Function Name: getStart
	Purpose: gets the player's starting tile
	@param Parameters: none
	@return Return Value: Domino object of player's starting tile
	Assistance Received: none
	********************************************************************* */
	public Domino getStart() {
		/**
		 * Stack::get()
		 * Stack::getSize()
		 */
		return boneyard.get(boneyard.getSize() - 1);
	}
	/**********************************************************************
	Function Name: getHandSize
	Purpose: gets the size of the player's hand
	@param Parameters: none
	@return Return Value: integer value of the player's current hand size
	Assistance Received: none
	********************************************************************* */
	public int getHandSize() {
		return handsize;
	}
	/**********************************************************************
	Function Name: getPass
	Purpose: gets if the player passed last turn
	@param Parameters: none
	@return Return Value: Boolean value that indicates if the player passed last turn
	Assistance Received: none
	********************************************************************* */
	public boolean getPass() {
		return didPass;
	}
	/**********************************************************************
	Function Name: getHand
	Purpose: gets the player's hand as an array of Dominoes
	@param Parameters: none
	@return Return Value: An array of Dominoes that holds the player hand
	Assistance Received: none
	********************************************************************* */
	public Domino[] getHand() {
		return hand;
	}
	/**********************************************************************
	Function Name: getHandString
	Purpose: gets the player's hand as a string
	@param Parameters: none
	@return Return Value: string that holds the player hand
	Assistance Received: none
	********************************************************************* */
	public String getHandString() {
		/**
		 * Domino::getString()
		 */
		String retStr = new String();
		for (int count = 0; count < handsize; count++) {
			retStr += hand[count].getString() + " ";
		}
		return retStr;
	}
	/**********************************************************************
	Function Name: setScore
	Purpose: Sets a player's total score
	@param Parameters: integer input that score will be set to 
	@return Return Value: none
	Assistance Received: none
	********************************************************************* */
	public void setScore(int input) {
		score = input;
	}
	/**********************************************************************
	Function Name: setPass
	Purpose: Sets if the player passed last turn
	@param Parameters: boolean input that if the player passed last turn will be set to
	@return Return Value: none
	Assistance Received: none
	********************************************************************* */
	public void setPass(boolean input) {
		didPass = input;
	}
	/**********************************************************************
	Function Name: setHand
	Purpose: Sets the player's hand
	@param Parameters: array of Dominoes that the hand will be set to
	@return Return Value: none
	Assistance Received: none
	********************************************************************* */
	public void setHand(Domino[] input) {
		/**
		 * Domino::copy()
		 */
		for (int count = 0; count < input.length; count++) {
			hand[count].copy(input[count]);
		}
		handsize = input.length;
	}
	/**********************************************************************
	Function Name: drawDomino
	Purpose: draws up to MAX_HAND_SIZE dominoes 
	@param Parameters: none
	@return Return Value: none
	Assistance Received: none
	********************************************************************* */
	public void drawDomino() {
		/**
		 * Stack::getSize()
		 * Domino::copy()
		 */
		handsize = 0;
		/** draws up to MAX HAND SIZE or until boneyard is empty */
		for (int count = 0; count < MAX_HAND_SIZE; count++) {
			/** if boneyard is empty, stop drawing */
			if (boneyard.getSize() <= 0) {
				break;
			}
			/** draws and adds domino to hand */
			hand[count].copy(boneyard.draw());
			/** updates handsize */
			handsize++;
		}
	}
	/**********************************************************************
	Function Name: handSort
	Purpose: sorts the hand by moving empty dominoes to the higher indexes
	@param Parameters: none
	@return Return Value: none
	Assistance Received: none
	********************************************************************* */
	public void handSort() {
		/**
		 * Domino::getColor()
		 * Domino::copy()
		 * Domino::setColor()
		 */
		/** for loops through hand */
		for (int count = 0; count < MAX_HAND_SIZE; count++) {
			if (hand[count].getColor() == 'E') {
				/**
				 * if there are any empty tiles, look for the first tile from
				 * the back that is not empty
				 */
				for (int countBack = MAX_HAND_SIZE - 1; countBack > count; countBack--) {
					if (hand[countBack].getColor() != 'E') {
						/**
						 * copy the values of the non empty tile into the empty
						 * tile and set the tile's original index to empty
						 */
						hand[count].copy(hand[countBack]);
						hand[countBack].setColor('E');
						break;
					}
				}
			}
		}
	}
	/**********************************************************************
	Function Name: handScorePenalty
	Purpose: calculate the player's penalty for not playing cards
	@param Parameters: none
	@return Return Value: integer of the value that should be subtracted from their score
	Assistance Received: none
	********************************************************************* */
	public int handScorePenalty() {
		/** Domino::getValue()*/

		int score = 0;
		/** adds up the values of the tiles in the player's hand*/
		for (int count = 0; count < handsize; count++) {
			score += hand[count].getValue();
		}
		return score;
	}
	/**********************************************************************
	Function Name: emptyHand
	Purpose: empties the player's hand
	@param Parameters: none
	@return Return Value: none
	Assistance Received: none
	********************************************************************* */
	public void emptyHand() {
		/** Domino::setColor()*/

		/** sets all dominoes in the hand to empty*/
		for (int count = 0; count < MAX_HAND_SIZE; count++) {
			hand[count].setColor('E');
		}
	}
	/**********************************************************************
	Function Name: placeDomino
	Purpose: plays a domino from the hand 
	@param Parameters: integer tile, the index of the tile in hand
				integer location, index on the field that the tile will be played at
				Board object field that the tile will be played on
	@return Return Value: none
	Assistance Received: none
	********************************************************************* */
	public boolean placeDomino(int tile, int location, Board field) {
		/**
		 * Domino::copy() 
		 * Player::handSort()
		 */
		if (tryPlaceDomino(tile, location, field)) {
			field.getStacks()[location].copy(hand[tile]);
			/**sets that tile to empty and lowers the handsize*/
			hand[tile].setColor('E');
			handsize--;
			handSort();
			/** set player as not passing*/
			didPass = false;
			/** true is legal move*/
			return true;
		} else {
			/** -1 for illegal move*/
			return false;
		}
	}
	/**********************************************************************
	Function Name: parseStackName
	Purpose: parse a string of a stack name into a location on the board
	@param Parameters: string input of a stack name
	@return Return Value: integer index of the stack
	Assistance Received: none
	********************************************************************* */
	public int parseStackName(String input) {
		/**
		 * String::charAt()
		 */

		/** stackNumber fails translation by default*/
		int stackNumber = -1;
		/** if the first character is the computer's color, the index begins at
		* zero*/
		if (input.charAt(0) == COMPUTER) {
			stackNumber = 0;
		}
		/** if the first character is the human's color, the index beings at six,
		* where the player's side of the board starts*/
		else if (input.charAt(0) == HUMAN) {
			stackNumber = Board.PLAYER_TILE_START;
		}

		/** if the second character is a digit, translate char into a number to be
		 *added to stackNumber. Otherwise, translation fails*/
		if (input.charAt(1) >= '1' && input.charAt(1) <= '9') {
			/** 48 is the decimal value subtracted from an ASCII number character
			 to obtain its value
			 one is more is subtracted because stacks start numbering from 1,
			 but the index starts at 0*/
			stackNumber += (input.charAt(1) - 49);
		} else {
			stackNumber = -1;
		}
		/** if the resulting stackNumber is negative, or exceeds the maximum
		number of stacks, the translation failed*/
		if (stackNumber < 0 || stackNumber >= Board.MAX_STACKS) {
			stackNumber = -1;
		}
		/** -1 indicates failed translation*/
		return stackNumber;
	}
	/**********************************************************************
	Function Name: tryPlaceDomino
	Purpose: checks if the move is legal
	@param Parameters: integer tile, the index of the tile in hand
				integer location, index on the field that the tile will be played at
				Board object field that the tile will be played on
	@return Return Value: a boolean that holds if the move is legal
	Assistance Received: none
	********************************************************************* */
	public boolean tryPlaceDomino(int tile, int location, Board field) {
		/**
		 * Domino::getColor() 
		 * Domino::getDouble() 
		 * Domino::getValue()
		 */

		/** default is illegal move*/
		boolean canPlace = false;
		/** checks if the tile is empty*/
		if (hand[tile].getColor() == 'E') {
			/** illegal move*/
			return canPlace;
		}
		/** if tile index exceeds handsize*/
		if (tile >= handsize) {
			/** illegal move*/
			return canPlace;
		}

		/** if the tile is a double*/
		if (hand[tile].getDouble()) {
			/** if the location is also a double*/
			if (field.getStacks()[location].getDouble()) {
				/** check if value of tile is greater*/
				if (hand[tile].getValue() > field.getStacks()[location]
						.getValue()) {
					/** if so, the tile can be played*/
					canPlace = true;
					return canPlace;
				}
				/** -1 for illegal move*/
				else {
					return canPlace;
				}
			}
			/** if location is not a double*/
			else {
				/** the double tile can be played*/
				canPlace = true;
				return canPlace;
			}
		} else {
			/** check for if value of tile is greater*/
			if (hand[tile].getValue() >= field.getStacks()[location].getValue()) {
				/** if so, the tile can be played*/
				canPlace = true;
				return canPlace;
			}
			/** -1 for illegal move*/
			else {
				return canPlace;
			}
		}
	}
	
	/***********************************************************************
	Function Name: shuffleDeck
	Purpose: shuffles the boneyard
	@param Parameters: none
	@return Return Value: none
	Assistance Received: none
	********************************************************************* */
	public void shuffleDeck() {
		/**
		 * Stack::shuffleDeck()
		 */
		boneyard.shuffleDeck();
	}
	/**********************************************************************
	Function Name: thinkCPU
	Purpose: allows the computer algorithm to play. Needs to be extended by subclasses
	@param Parameters: Board object field
	@return Return Value: String containing the move
	Assistance Received: none
	********************************************************************* */
	abstract String thinkCPU(Board field);
	/**********************************************************************
	Function Name: beginStack
	Purpose: puts the top six tiles of the boneyard as the stacks. Needs to be extended
	@param Parameters: Board object field to place the dominoes on
	@return Return Value: none
	Assistance Received: none
	********************************************************************* */
	abstract void beginStack(Board field);

	
}
