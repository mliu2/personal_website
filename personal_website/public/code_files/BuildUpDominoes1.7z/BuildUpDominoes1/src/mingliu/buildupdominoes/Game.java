package mingliu.buildupdominoes;

public class Game {
	protected static final String ILLEGAL = "Illegal Move.";
	protected static final int  MAX_HANDS = 4;
	protected Human playerH;
	protected Computer playerC;
	protected Board stacks;
	/**1 is player, 0 is computer*/
	protected int turn;
	protected int hands;
	
	
	public Game() {
		hands = 0;
		turn = -1;
		stacks = new Board();
		playerC = new Computer();
		playerH = new Human();
	}

	/**********************************************************************
	Function Name: getBoard
	Purpose: gets the Board object
	@param Parameters: none
	@return Return Value: Board object being used
	Assistance Received: none
	********************************************************************* */
	public Board getBoard() {
		return stacks;
	}
	/**********************************************************************
	Function Name: getComp
	Purpose: gets the Computer object
	@param Parameters: none
	@return Return Value: Computer object being used
	Assistance Received: none
	********************************************************************* */
	public Computer getComp() {
		return playerC;
	}
	/**********************************************************************
	Function Name: getHuman
	Purpose: gets the Human object
	@param Parameters: none
	@return Return Value: Human object being used
	Assistance Received: none
	********************************************************************* */
	public Human getHuman() {
		return playerH;
	}
	/**********************************************************************
	Function Name: getHands
	Purpose: gets an integer that represents which hand is currently being played
	Parameters: none
	Return Value: an integer that represents which hand is currently being played
	Assistance Received: none
	********************************************************************* */
	public int getHands() {
		return hands;
	}
	/**********************************************************************
	Function Name: getTurn
	Purpose: gets an integer that represents whose turn it is
	@param Parameters: none
	@return Return Value: an integer that represents whose turn it is; 0 is for computer, 1 is for player
	Assistance Received: none
	********************************************************************* */
	public int getTurn() {
		return turn;
	}
	/**********************************************************************
	Function Name: getWinner
	Purpose: Gets the winner of the game 
	@param Parameters: none
	@return Return Value: A String holding who won with a message
	Assistance Received: none
	********************************************************************* */
	public String getWinner() {
		/**
		 * Player::getScore()
		 */
		if (playerH.getScore() > playerC.getScore()){
			return "We have won, yes?";
		} else if (playerH.getScore() < playerC.getScore()){
			return "The computer wins. This time.";
		} else {
			return "It seems like there was no winner here.";
		}
	}

	/**********************************************************************
	Function Name: setTurn
	Purpose: sets an integer that represents whose turn it is
	@param Parameters: An integer between 0 and MAX_HANDS, inclusive
	@return Return Value: none
	Assistance Received: none
	********************************************************************* */
	public void setHands(int input) {
		/**validates input*/
		if (input >= 0 && input <= MAX_HANDS) {
			hands = input;
		}
	}
	/**********************************************************************
	Function Name: setTurn
	Purpose: Sets the integer that holds whose turn it is
	@param Parameters: integer input that determines whose turn it is
	@return Return Value: none
	Assistance Received: none
	********************************************************************* */
	public void setTurn (int input) {
		if (input == 0 || input == 1) {
			turn = input;
		}
	}
	/**********************************************************************
	Function Name: startTurn
	Purpose: Sets the integer that holds whose turn it is based on the players' top domino on the boneyard
	@param Parameters: none
	@return Return Value: none
	Assistance Received: none
	********************************************************************* */
	public void startTurn () {
		/**
		 * Player::getStart()
		 * Domino::getValue()
		 */
		if (playerC.getStart().getValue() > playerH.getStart().getValue()) {
			turn = 0;
		} else if (playerC.getStart().getValue() < playerH.getStart().getValue()) {
			turn = 1;
		} else {
			turn = -1;
		}
	}
	/**********************************************************************
	Function Name: newGame
	Purpose: Sets up the scores, hands, and stacks for a new game
	@param Parameters: none
	@return Return Value: none
	Assistance Received: none
	********************************************************************* */
	public void newGame() {
		/**
		 Player::setScore()
		 Computer::beginStack()
		 Human::beginStack()
		 Game::startTurn()
		 * */

		playerC.setScore(0);
		playerH.setScore(0);
		/**rests hand to 0, will be incremented when game starts*/
		hands = 0;

		/**gets the top 6 dominoes to make the stacks*/
		playerC.beginStack(stacks);
		playerH.beginStack(stacks);
		startTurn();
		return;
	}
	/**********************************************************************
	Function Name: beginHand
	Purpose: Begins a new hand
	@param Parameters: none
	@return Return Value: none
	Assistance Received: none
	********************************************************************* */
	public void beginHand() {
		/**
		 * Player::setScore()
		 * Board::getScore()
		 * Player::handScorePenalty()
		 * Player::emptyHand()
		 * Player::drawDomino()
		 * Player::handSort()
		 */
		if (hands > 0){
			playerC.setScore(playerC.getScore() + stacks.getScore(Player.COMPUTER) - playerC.handScorePenalty());
			playerH.setScore(playerH.getScore() + stacks.getScore(Player.HUMAN) - playerH.handScorePenalty());
		}
		/**empties both hands*/
		playerC.emptyHand();
		playerH.emptyHand();

		hands++;
		
		playerC.drawDomino();
		playerH.drawDomino();
		playerC.handSort();
		playerH.handSort();
	}
	/**********************************************************************
	Function Name: shuffleGame
	Purpose: shuffles both player's boneyards and gets a new start tile
	@param Parameters: none
	@return Return Value: none
	Assistance Received: none
	********************************************************************* */
	public void shuffleGame() {
		/**
		 * Player::shuffleDeck()
		 * Player::getStart()
		 */
		do {
			/**shuffles both player's boneyards*/
			playerC.shuffleDeck();
			playerH.shuffleDeck();
			/**this will continue until the start values are not equal*/
		} while (playerC.getStart() == playerH.getStart());
		startTurn();
		
	}
	/**********************************************************************
	Function Name: checkEndHand
	Purpose: Checks if a new hand needs to start 
	@param Parameters: none
	@return Return Value: none
	Assistance Received: none
	********************************************************************* */
	public void checkEndHand() {
		/**
		 * Player::getHandSize()
		 * Player::getPass()
		 * Game::beginHand()
		 * Player::setPass()
		 */
		/** if both hands are empty or if both players pass*/
		if ((playerC.getHandSize() == 0 && playerH.getHandSize() == 0) || (playerC.getPass() && playerH.getPass())) {
			beginHand();
			playerH.setPass(false);
			playerC.setPass(false);
		}
	}
	/**********************************************************************
	Function Name: humanPlay
	Purpose: 
	@param Parameters: integer to the index of the domino in the hand being played
	 				   integer to the index of the stack being played on
	@return Return Value: String confirming the move, or if the move was illegal, stating the fact
	Assistance Received: none
	********************************************************************* */
	public String humanPlay(int indexHand, int indexStacks) {
		/**
		 * Player::placeDomino()
		 * Player::getHandSize()
		 * Player::setPass()
		 * Board::getStacks()
		 * Domino::getString()
		 * Board::indexToStack()
		 */
		/**validate input*/
		if (indexHand >= 0 && indexHand < playerH.getHandSize()){
			if (playerH.placeDomino(indexHand, indexStacks, stacks)){
				playerH.setPass(false);
				/**if move is allowed, do it.*/
				return "You played "+ stacks.getStacks()[indexStacks].getString() + " on "+ stacks.indexToStack(indexStacks);
			}else{
				/**if the move is not allowed, return illegal move message*/
				return ILLEGAL;
			}
		} else {
			return "Illegal Domino Selection.";
		}
	}
	/**********************************************************************
	Function Name: canHumanPass
	Purpose: Determines if the human player is allowed to pass
	@param Parameters: none
	@return Return Value: boolean, true if the human can pass, false if the human still has moves left
	Assistance Received: none
	********************************************************************* */
	public boolean canHumanPass() {
		/**
		 * Human::thinkCPU()
		 * Player::setPass()
		 */
		if (playerH.thinkCPU(stacks).equals(Player.PASS)) {
			playerH.setPass(true);
			return true;
		} else {
			return false;
		}
	}
	/**********************************************************************
	Function Name: help
	Purpose: Calls the computer script to determine the human's best move
	@param Parameters: none
	@return Return Value: A String holding the computer's suggestion
	Assistance Received: none
	********************************************************************* */
	public String help() {
		/**
		 * Human::thinkCPU()
		 */
		return playerH.thinkCPU(stacks);
	}
	/**********************************************************************
	Function Name: compPlay
	Purpose: Allows the computer to play
	@param Parameters: none
	@return Return Value: A String holding the computer's move to be displayed
	Assistance Received: none
	********************************************************************* */
	public String compPlay () {
		/**
		 * Computer::playCPU()
		 */
		return playerC.playCPU(stacks);
	}
	
	

}
